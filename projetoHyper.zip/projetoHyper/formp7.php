<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Martian+Mono:wght@600&display=swap" rel="stylesheet">
</head>
  <body>
    <nav class="navbar navbar-expand-lg bg-dark md-4 sm-4 ">
      <div class="container-fluid md-4 sm-4" >
        <a class="navbar-brand text-white mouseefeito md-4 sm-4" href="index.html"  style="font-family: 'Martian Mono', monospace;"> <img src="./img/redguy-removebg-preview.png" style="width: 44px;" >Petabyte</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse md-4 sm-4" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0 md-4 sm-4 ">
            <li class="nav-item md-4 sm-4 ">
              <a class="nav-link active text-white mouseefeito md-4 sm-4 aria-current="page" href="index.html">Home</a>
            </li>
            <li class="nav-item dropdown md-4 sm-4">
              <a class="nav-link dropdown-toggle text-white mouseefeito md-4 sm-4" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Hardware
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item mouseefeito md-4 sm-4" href="#">Processadores</a></li>
                <hr>
                <li><a class="dropdown-item mouseefeito md-4 sm-4 " href="#">Placa de Video</a></li>
              <hr>
                <li><a class="dropdown-item mouseefeito md-4 sm-4 " href="#">Ssd</a></li>
              </ul>
            </li>
            <li class="nav-item md-3 sm-3">
              <a class="nav-link active text-white mouseefeito md-4 sm-4" aria-current="page" href="#">Suporte</a>
            </li>
          </ul>
          <img src="./img/carrinho-de-compras.png" class="me-4 md-4 sm-4" style="width: 30px;" alt="">
          
        </div>
      </div>
    </nav>
      <body>
  
        <div class="container-fluid gradient " style="width: 30%";>
          <br>
           
          <div class="card row mt-5 shadow-lg p-3 mb-5 bg-white rounded">
              
            
              <h3 class="text-center">Crie uma conta</h3>
                <div class="card-body " >
                  <hr>
                    <form name="frAlugFilme" action="produto7f.html" method="post" id="frAlugFilme" class="frAlugFilme">
    
                              <div class="row mt-3">
                                <div class="col-md-6 sm-12">
                                  <label for="inpnome" class="form-label"></label>
                                  <input type="text" class="form-control" id="inpnome" required="required" placeholder="Nome">
                                </div>
                              
                                <div class="col-md-6 sm-12">
                                  <label for="inpcpf" class="form-label"></label>
                                  <input type="number" class="form-control " id="inpcpf" required="required" placeholder="Cpf">
                                </div>
                                </div>  
                                  <div class="row mt-3"> 
                                    <div class="col-md-12">
                                      <label for="inpemail" class="form-label"></label>
                                      <input type="email" class="form-control" id="inpemail" required="required" placeholder="Insíra seu e-mail">
                                    </div>
                                  </div>  
                                  <div class="row mt-3">
                                    <div class="col-md-12">
                                      <label for="inpsenha" class="form-label"></label>
                                      <input type="password" class="form-control" id="inpsenha" placeholder="Insíra uma senha" required="required ">
                                    </div>
                                  </div>  
                                  <div class="mb-3 form-check mt-3">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Salvar senha</label>
                                  </div>
                                    <div class="row mt-3">
                                      <div class="col-md-12">
                                      <a href="loginp7.html"><button type="button" class="btn btn-md mudarv mt-3 text-white b voltar">Voltar</button></a>            
                                    <a href="produto7f.html"><button type="submit" class="btn btn-md mudarc text-white mt-3 efect">Finalizar</button></a>  
                                    </div>  
                            </div>
                        </form>
                    </div>
                </div>  
            </div>   
        </div>
  
  
  <!-- Modal -->
  <div class="modal fade" id="bmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="alert alert-warning" role="alert">
                Cadastrado com sucesso!
                <img src="./img/o-removebg-preview.png" style="width: 30px;" alt="">
              </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>