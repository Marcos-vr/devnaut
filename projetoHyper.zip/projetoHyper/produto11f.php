<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitor Gamer Ninja Byakugan, 23,8", Full HD, 75Hz, IPS, FreeSync, HDMI/VGA/DP, MGN-005-23</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  
</head>
<body class="" style="background-attachment: fixed;">
  <nav class="navbar navbar-expand-lg bg-dark md-4 sm-4 ">
    <div class="container-fluid md-4 sm-4" >
      <a class="navbar-brand text-white mouseefeito md-4 sm-4" href="index.html"  style="font-family: 'Martian Mono', monospace;"> <img src="./img/redguy-removebg-preview.png" style="width: 44px;" >Petabyte</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse md-4 sm-4" id="navbarSupportedContent md-4 sm-4">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 md-4 sm-4 ">
          <li class="nav-item md-4 sm-4">
            <a class="nav-link active text-white mouseefeito md-4 sm-4" aria-current="page" href="index.html">Home</a>
          </li>
          <li class="nav-item dropdown md-4 sm-4">
            <a class="nav-link dropdown-toggle text-white mouseefeito md-4 sm-4" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Hardware
            </a>
            <ul class="dropdown-menu md-4 sm-4">
              <li><a class="dropdown-item mouseefeito md-4 sm-4" href="#">Processadores</a></li>
              <hr>
              <li><a class="dropdown-item mouseefeito md-4 sm-4 " href="#">Placa de Video</a></li>
            <hr>
              <li><a class="dropdown-item mouseefeito md-4 sm-4 " href="#">Ssd</a></li>
            </ul>
          </li>
          <li class="nav-item md-4 sm-4">
            <a class="nav-link active text-white mouseefeito md-4 sm-4" aria-current="page" href="#">Suporte</a>
          </li>
        </ul>
        <img src="./img/carrinho-de-compras.png" class="me-4 md-4 sm-4" style="width: 30px;" alt="">
         
       
        
      </div>
    </div>
  </nav>
    
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-5 sm-5" style="margin: 60px;">
                <img src="img/pdt10.png" class="img-fluid rounded-start" alt="" >
            </div>
            <div class="col-md-5 sm-5">
              <br>
              <br>
                <div class="container">
                    <div class="mt-3 bg-dark text-white" style="border: 1px solid gray; margin: 10px; padding: 10px; padding-bottom: 1em; border-radius: 10px;">
                      <h5>Descrição</h5>
                      <p>
                        7200 DPI - Maior velocidade para executar com agilidade seus inimigos. Excelente formato para diversas pegadas. Retro-lluminaçao para mais estilo em seu Pegasus!Boa performance garantida com 4000 FPS,  tempo de resposta de 1ms e Taxa de Atuação de 10G.  Altere entre 3 perfis pré-configurados com toque de um botão! 
                      </p>
                      <br>
                      <br>
                      <hr>
                        <div class="row d-flex">
                        <div class="col-md-12" style="padding: 40px;">  
                          <a href=""  class="btn btn-verde comprar" style="width: 100%; padding: 5px;"><h4 style="color: gray;">Comprar</h4></a>
                        </div>      
                        </div>    
                    </div>
                    
                </div>
            </div>
        
        
        
        </div>

    </div>
      <script src="script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>