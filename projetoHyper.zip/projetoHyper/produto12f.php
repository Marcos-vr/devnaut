<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .card {
            position: relative;
            overflow: hidden;
        }

        .esconderBotao {
            display: none;
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }

        .card:hover .esconderBotao {
            display: block;
        }
    </style>
</head>
<body>
    <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary cueva">
        <a href="produto2.php">
            <div class="card prod bg-tertiary">
                <img src="img/ryzen.png" class="img-top img-fluid rounded-start" alt="...">
                <div class="card-body">
                    <hr>
                    <p class="card-title text-black">
                        Processador AMD Ryzen 5 4600G 3.7GHz (4.2GHz Turbo), 6-Cores 12-Threads, Cooler Wraith Stealth
                    </p>
                </div>
            </div>
        </a>
        <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 699,99</small><small style="color: red;"> por:</small>
        <br>
        <strong style="color: green;">
            <h3>R$ 449,99</h3>
            <small> à vista </small>
        </strong>
        <button class="btn-success btn-lg esconderBotao">Adicionar ao carrinho</button>
    </div>
</body>
</html>
