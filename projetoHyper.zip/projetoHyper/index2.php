<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Petabyte</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="lib/owlCarousel/dist/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="lib/owlCarousel/dist/assets/owl.theme.default.min.css">

  <style>

  </style>
</head>

<body class="bg-body-secondary">




  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-dark md-4 sm-4 ">
    <div class="container-fluid md-4 sm-4">
      <a class="navbar-brand text-white mouseefeito md-4 sm-4" href="#" style="font-family: 'Martian Mono', monospace;"> <img src="./img/redguy-removebg-preview.png" style="width: 44px;">Petabyte</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse md-4 sm-4" id="navbarSupportedContent md-4 sm-4">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 md-4 sm-4 ">
          <li class="nav-item md-4 sm-4">
            <a class="nav-link active text-white mouseefeito md-4 sm-4" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item dropdown md-4 sm-4">
            <a class="nav-link dropdown-toggle text-white mouseefeito md-4 sm-4" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Hardware
            </a>
            <ul class="dropdown-menu md-4 sm-4">
              <li><a class="dropdown-item mouseefeito md-4 sm-4" href="#">Processadores</a></li>
              <hr>
              <li><a class="dropdown-item mouseefeito md-4 sm-4 " href="#">Placa de Video</a></li>
              <hr>
              <li><a class="dropdown-item mouseefeito md-4 sm-4 " href="#">Ssd</a></li>
            </ul>
          </li>
          <li class="nav-item md-4 sm-4">
            <a class="nav-link active text-white mouseefeito md-4 sm-4" aria-current="page" href="#">Suporte</a>
          </li>
        </ul>
        <img src="./img/carrinho-de-compras.png" class="me-4 md-4 sm-4" style="width: 30px;" alt="">

        <a class="nav-link dropdown-toggle text-white mouseefeito1 md-4 sm-4" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <img src="./img/do-utilizador (1).png" class="me-4 md-4 sm-4" style="width: 30px;" alt=""><small class="text-white"><strong>User123</strong></small>
        </a>



      </div>
    </div>
  </nav>





  <!-- banner rotativo -->


  <div id="carouselExampleIndicators" class="carousel slide">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./img/banner4.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="./img/banner5.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="./img/banner6 (1).jpg" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

  <br>



  <!-- Incio dos Produtos -->

  <div class="container" style="justify-content: center;">
    <div>
      <h2 style="color: rgb(235, 3, 3); text-align: start; ">Para todos os públicos</h2>
    </div>

    <div class="container row mt-3">

      <div class="col-md-6 sm-12 sm-12 py-1">
        <h4 style="margin-left: 25px;">Home office</h4>
        <img src="img/homeoffice.jpg" alt="" class="img-fluid zoom" style="border-radius:10px;">
      </div>
      <div class="col-md-6 sm-12 sm-12 py-1">
        <h4 style="margin-left: 25px;">Gamers</h4>
        <img src="img/gamer.jpg" alt="" class="img-fluid zoom" style="border-radius:10px;">

      </div>
    </div>

    <br>




    <div>
      <h2 style="color: rgb(235, 3, 3); text-align: start; ">Mais vendidos</h2>
    </div>


    <div class="row bg">
      <div class="col-md-2 sm-12 py-2 sm-12 py-2">
        <a href="produto1f.html">
          <div class="card prod" style="width: 18rem; border: none;">
            <img src="./img/pdt1.png" class="card-img-top" alt="...">
            <div class="card-body" style="height:15rem">
              <hr>
        </a>
        <h5 class="card-title"></h5>
        <small class="card-text">Monitor Gamer Ninja Byakugan, 23,8", Full HD, 75Hz, IPS, FreeSync, HDMI/VGA/DP, MGN-005-23</small>

        <div style="color:green;">

          <strong>
            <span>R$ 399,99</span>
            <small> à vista </small>
          </strong>
        </div>
        </a>
      </div>
    </div>
  </div>

  <div class="col-md-2 sm-12 py-2 sm-12 py-2">
    <a href="produto2f.html">
      <div class="card prod" style="width: 15rem; border: none;">
        <img src="./img/ryzen.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
    </a>
    <h5 class="card-title"></h5>
    <small class="card-text">AMD Ryzen 5 4600G 3.7GHz (4.2GHz Turbo), 6-Cores 12-Threads, Cooler Wraith Stealth, AM4, 100-100000147BOX</small>
    <div style="color:green;">

      <strong>
        <span>R$ 449,99</span>
        <small> à vista </small>
      </strong>
    </div>
  </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto3f.html"> <img src="./img/pdt3.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Placa de Vídeo PNY NVIDIA GeForce RTX 4060 VERTO Dual Fan, 8GB, GDDR6, DLSS, Ray Tracing, VCG40608DFXPB1</small>
      <div style="color:green;">

        <strong>
          <span>R$ 1799,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto4f.html"> <img src="./img/ssd.jpg" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">SSD WD Blue SN570 NVMe M.2, 500GB, PCIe Gen3 x4, NVMe v1.4, Leitura 3500MBs e Gravação 2300MBs, WDS500G3B0C</small>
      <div style="color:green;">

        <strong>
          <span>R$ 149,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto5f.html"> <img src="./img/pdt4.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Processador Intel Core i5 10400F 2.90GHz (4.30GHz Turbo), 10ª Geração, 6-Cores 12-Threads, LGA 1200, BX8070110400F</small>
      <div style="color:green;">
        <strong>
          <span>R$ 399,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto6.html"> <img src="./img/pdt5.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Gabinete Gamer Montech x3 Glass, Mid Tower, White, ATX, 6 Fans, Vidro Temperado</small>
      <div style="color:green;">

        <strong>
          <span>R$ 249,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  </div>

  <br>.

  <div class="row mt-3">
    <div class="col-md-2 sm-12 py-2">
      <div class="card prod" style="width: 15rem; border: none;">
        <a href="produto7.html"> <img src="./img/pdt6.png" class="card-img-top" alt="...">
          <div class="card-body" style="height: 15rem;">
            <hr>
        </a>
        <h5 class="card-title"></h5>
        <small class="card-text">Gabinete Gamer Redragon Superion, Mid Tower, Vidro Temperado, Black, ATX, Sem Fonte, Sem Fan, GC-MB211</small>
        <div style="color:green;">

          <strong>
            <span>R$ 219,99</span>
            <small> à vista </small>
          </strong>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto8.html"> <img src="./img/pdt7.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Microfone Gamer Streamer Redragon Blazar C/ Tripé, USB, Black, GM300</small>
      <div style="color:green;">
        <strong>
          <span>R$ 279,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto9.html"> <img src="./img/pdt8.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Microfone HyperX QuadCast S, USB, LED RGB, HMIQ1S-XX-RG/G, Codec ACC/AAC </small>
      <br>
      <div style="color:green;">
        <br>
        <strong>
          <span>R$ 799,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto10.html"> <img src="./img/pdt9.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Headset Gamer T-Dagger Eiger, 3.5mm + USB, Green, T-RGH208</small>
      <div style="color:green;">

        <strong>
          <span>R$ 99,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto11.html"> <img src="./img/pdt10.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>
      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Mouse Gamer Redragon Pegasus M705, 7200 DPI, 6 Botões, Black</small>
      <div style="color:green;">

        <strong>
          <span>R$ 169,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>

  <div class="col-md-2 sm-12 py-2">
    <div class="card prod" style="width: 15rem; border: none;">
      <a href="produto12.html"> <img src="./img/pdt11.png" class="card-img-top" alt="...">
        <div class="card-body" style="height: 15rem;">
          <hr>

      </a>
      <h5 class="card-title"></h5>
      <small class="card-text">Mouse Gamer Logitech Hero G502, 16000 DPI, 11 Botões, Ajuste de Peso, RGB, Black, 910-005550</small>
      <div style="color:green;">

        <strong>
          <span>R$ 299,99</span>
          <small> à vista </small>
        </strong>
      </div>
    </div>
  </div>
  </div>
  </div>
  </div>
  <br>


  </div>
  <!-- footer -->



  <footer class="bg-dark">
    <br>
    <div class="container footer-one">
      <div class="row mt-3">

        <div class="col-md-2 sm-12 py-2 sm-2">
          <img src="" alt="">
        </div>


        <div class="col-md-2 sm-12 py-2 sm-2 bg-dark">
          <nav>
            <ul class="" style="list-style: none;">
              <a href="#" style="text-decoration: none;">
                <li class=" bg-dark text-white ">Termos de uso</li>
              </a>
              <a href="" style="text-decoration: none;">
                <li class=" bg-dark text-white">Políticas de privacidade</li>
              </a>
              <a href="" style="text-decoration: none;">
                <li class=" bg-dark text-white">Sobre nós</li>
              </a>
            </ul>
          </nav>
        </div>

        <div class="col-md-4 sm-2 mt-5" style="text-align: center; ">
          <p class="text-white">SIGA-NOS</p>
          <a href="https://www.instagram.com/" target="_blank"><img src="img/instagram.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://br.linkedin.com/" target="_blank"><img src="img/linkedin.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://www.facebook.com/?locale=pt_BR" target="_blank"><img src="img/facebook.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://twitter.com/login?lang=pt" target="_blank"><img src="img/twitter.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://www.youtube.com/?hl=pt-br" target="_blank"><img src="img/certo.png" img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
        </div>




      </div>

      <div class="row mt-3 ">
        <div class="col-md-12 text-white" style="justify-content: center;">
          <p style="text-align: center;">&copy; 2023 - Todos os direitos reservados</p>
          <p style="text-align: center;">Entre em contato pelo e-mail: contato@exemplo.com</p>
        </div>

      </div>
    </div>

    </div>
    <br>
    <br>

  </footer>
  <script src="lib/owlCarousel/dist/owl.carousel.min.js"></script>
  <script src="lib/jQuery/jquery.min.js"></script>
  <script src="script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>