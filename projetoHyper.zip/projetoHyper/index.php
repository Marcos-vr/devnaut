<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hyper</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="lib/owlCarousel/dist/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="lib/owlCarousel/dist/assets/owl.theme.default.min.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Play:wght@400;700&display=swap" rel="stylesheet">
  <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
  <link rel="manifest" href="/site.webmanifest">
  <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
  <meta name="msapplication-TileColor" content="#da532c">
  <meta name="theme-color" content="#ffffff">
</head>

<body class="bg-body-secondary">




  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-dark md-4 sm-4 fixed-top">
    <div class="container-fluid md-4 sm-4">
      <a class="navbar-brand text-white mouseefeito md-4 sm-4" href="#" style="font-family: 'Martian Mono', monospace;"><img src="img/logo.png" alt="" width="180px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse md-4 sm-4" id="navbarSupportedContent md-4 sm-4">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 md-4 sm-4 ">
          <li class="nav-item md-4 sm-4">
            <a class="nav-link active text-white mouseefeito md-4 sm-4" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item dropdown md-4 sm-4">
            <a class="nav-link dropdown-toggle text-white mouseefeito md-4 sm-4" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Hardware
            </a>
            <ul class="dropdown-menu md-4 sm-4">
              <li class="drophov"><a class="dropdown-item  md-4 sm-4 " href="#">Processadores</a></li>
              <hr>
              <li class="drophov"><a class="dropdown-item  md-4 sm-4 " href="#">Placa de Video</a></li>
              <hr>
              <li class="drophov"><a class="dropdown-item  md-4 sm-4 " href="#">Ssd</a></li>
            </ul>
          </li>
          <li class="nav-item md-4 sm-4">
            <a class="nav-link active text-white mouseefeito md-4 sm-4" aria-current="page" href="#">Suporte</a>
          </li>
        </ul>
        <img src="./img/carrinho-de-compras.png" class="me-4 md-4 sm-4" style="width: 30px;" alt="">



      </div>
    </div>
  </nav>

  <!-- banner rotativo -->
  <br><br>

  <div id="carouselExampleIndicators" class="carousel slide mt-3">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./img/banner4.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="./img/banner5.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="./img/banner6 (1).jpg" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

  <br>



  <!-- Incio dos Produtos -->
  <div class="container ">
    <div>
      <h2 class=" shadow rounded bg-dark" style="padding:10px; font-family: 'Play', sans-serif; font-weight: 700; font-style: normal; color: #776eb8;">Para todos os públicos</h2>
    </div>

    <div class=" row mt-3">

      <div class="col-md-6 sm-12 sm-12 py-1">
        <h4 style="margin-left: 25px;">Home office</h4>
        <img src="img/homeoffice.jpg " alt="Pc" class="img-fluid zoom " style="border-radius:10px;">
      </div>
      <div class="col-md-6 sm-12 sm-12 py-1">
        <h4 style="margin-left: 25px;">Gamers</h4>
        <img src="img/gamer.jpg " alt="Pc" class="img-fluid zoom" style="border-radius:10px;">

      </div>
    </div>
  </div>
  <br>
  <div class="container-fluid ">

    <h2 class=" anta-regular shadow rounded bg-dark" style="padding:10px; font-family: 'Play', sans-serif; font-weight: 700; font-style: normal; color: #776eb8;">Mais vendidos</h2>
    <hr>
  </div>

  <!-- Área dos cards -->
  <div class="container-fluid">
    <div class="row mt-1 g-3 central">
      <br>
      <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
        <a href="produto1.php">
          <div class="card prod bg-tertiary">
            <img src="img/compra1.png" class="img-top img-fluid rounded-start" alt="...">
            <div class="card-body">
              <hr>
              <p class="card-title text-black">
                Monitor Gamer Ninja Byakugan, 23,8", Full HD, 75Hz, IPS, FreeSync, HDMI/VGA/DP
              </p>
        </a>
        <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 599,99</small><small style="color: red;"> por:</small>
        <strong style="color: green;">
          <h3>R$ 399,99</h3>
          <small> à vista </small>
        </strong>
      </div>

    </div>
  </div>




  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary cueva">
    <a href="produto2.php">
      <div class="card prod bg-tertiary">
        <img src="img/ryzen.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Processador AMD Ryzen 5 4600G 3.7GHz (4.2GHz Turbo), 6-Cores 12-Threads, Cooler Wraith Stealth
          </p>
        </div>
      </div>
    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 699,99</small><small style="color: red;"> por:</small>
    <br>
    <strong style="color: green;">
      <h3>R$ 449,99</h3>
      <small> à vista </small>
    </strong>
    <button class="btn-success btn-lg esconderBotao">Adicionar ao carrinho</button>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="produto3.php">
      <div class="card prod bg-tertiary">
        <img src="img/pdt3.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Placa de Vídeo PNY NVIDIA GeForce RTX 4060 VERTO Dual Fan, 8GB, GDDR6, DLSS, Ray Tracing
          </p>
    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 2349,99</small><small style="color: red;"> por:</small>
    <br>
    <strong style="color: green;">
      <h3>R$ 1799,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="produto4.php">
      <div class="card prod bg-tertiary">
        <img src="img/ssd.jpg" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            SSD WD Blue SN570 NVMe M.2, 500GB, PCIe Gen3 x4, NVMe v1.4, Leitura 3500MBs e Gravação 2300MBs
          </p>
    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 199,99</small><small style="color: red;"> por:</small>
    <br>
    <strong style="color: green;">
      <h3>R$ 149,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="produto5.php">
      <div class="card prod bg-tertiary">
        <img src="img/pdt4.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Processador Intel Core i5 10400F 2.90GHz (4.30GHz Turbo), 10ª Geração, 6-Cores 12-Threads, LGA 1200
          </p>
    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 499,99</small><small style="color: red;"> por:</small>
    <br>
    <strong style="color: green;">
      <h3>R$ 399,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="">
      <div class="card prod bg-tertiary">
        <img src="img/pdt5.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Gabinete Gamer Montech x3 Glass, Mid Tower, White, ATX, 6 Fans, Vidro Temperado
          </p>

    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 359,99</small><small style="color: red;"> por:</small>

    <strong style="color: green;">
      <h3>R$ 199,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>
  <hr style="color:#e9ecef;">

  <!-- Dois banners pequenos -->

  <div class="row container centralo">
    <div class="col-md-6 col-sm-12 mt-3">
      <img src="img/bannerp.jpg" alt="" class="img-fluid rounded shadow filtro">
    </div>
    <div class="col-md-6 col-sm-12 mt-3">
      <img src="img/bannerp2.jpg" alt="" class="img-fluid rounded shadow filtro">
    </div>
  </div>

  <!-- Área cards 2 -->
  <hr style="color:#e9ecef;">

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <div class="card prod bg-tertiary">
      <a href="produto6.php">
        <img src="img/pdt6.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Gabinete Gamer Redragon Superion, Mid Tower, Vidro Temperado, Black, ATX, Sem Fonte, Sem Fan
          </p>
      </a>
      <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 299,99</small><small style="color: red;"> por:</small>
      <br>
      <strong style="color: green;">
        <h3>R$ 249,99</h3>
        <small> à vista </small>
      </strong>
    </div>
  </div>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="produto7.php">
      <div class="card prod bg-tertiary">
        <img src="img/pdt12.jpg" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Teclado Gamer Ninja Black Noir, RGB, Switch Membrana, ABNT2, Black, TC-GN-BKNR
          </p>

    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 99,99</small><small style="color: red;"> por:</small>

    <strong style="color: green;">
      <h3>R$ 79,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="produto8.php">
      <div class="card prod bg-tertiary">
        <img src="img/pdt7.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Microfone Gamer Fifine SuperFrame Edition SFM1, RGB, USB, Black, Com Braço Articulado
          </p>

    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 324,99</small><small style="color: red;"> por:</small>

    <strong style="color: green;">
      <h3>R$ 279,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>


  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="produto9.php">
      <div class="card prod bg-tertiary">
        <img src="img/pdt8.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Microfone HyperX QuadCast S, USB, LED RGB, HMIQ1S-XX-RG/G
          </p>

    </a>
    <br>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 799,99</small><small style="color: red;"> por:</small>

    <strong style="color: green;">
      <h3>R$ 599,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="">
      <div class="card prod bg-tertiary">
        <img src="img/pdt9.png" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Headset Gamer T-Dagger Eiger, 3.5mm + USB, Green, T-RGH208, Codec ACC/AAC
          </p>
          <br>
    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 159,99</small><small style="color: red;"> por:</small>

    <strong style="color: green;">
      <h3>R$ 99,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>

  <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 bg-tertiary">
    <a href="">
      <div class="card prod bg-tertiary">
        <img src="img/pdt13.jpg" class="img-top img-fluid rounded-start" alt="...">
        <div class="card-body">
          <hr>
          <p class="card-title text-black">
            Cadeira Gamer SuperFrame Cleric, Reclinável, 4D, Branco e Preto
          </p>
          <br>
    </a>
    <small style="color: red;">De </small><small style="text-decoration: line-through; color:red;">R$ 899,99</small><small style="color: red;"> por:</small>

    <strong style="color: green;">
      <h3>R$ 699,99</h3>
      <small> à vista </small>
    </strong>
  </div>
  </div>
  </div>

  <br class="pb-3">
  <hr style="color:#e9ecef;">

  <!-- footer -->

  <footer class="bg-dark">
    <br>
    <div class="container footer-one">
      <div class="row mt-3">

        <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 py-2 sm-2">
          <img src="" alt="">
        </div>


        <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 py-2 sm-2 bg-dark">
          <nav>
            <ul class="" style="list-style: none;">
              <a href="#" style="text-decoration: none;">
                <li class=" bg-dark text-white ">Termos de uso</li>
              </a>
              <a href="" style="text-decoration: none;">
                <li class=" bg-dark text-white">Políticas de privacidade</li>
              </a>
              <a href="" style="text-decoration: none;">
                <li class=" bg-dark text-white">Sobre nós</li>
              </a>
            </ul>
          </nav>
        </div>

        <div class="col-md-4 sm-2 mt-5" style="text-align: center; ">
          <p class="text-white">SIGA-NOS</p>
          <a href="https://www.instagram.com/" target="_blank"><img src="img/instagram.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://br.linkedin.com/" target="_blank"><img src="img/linkedin.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://www.facebook.com/?locale=pt_BR" target="_blank"><img src="img/facebook.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://twitter.com/login?lang=pt" target="_blank"><img src="img/twitter.png" class="img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
          <a href="https://www.youtube.com/?hl=pt-br" target="_blank"><img src="img/certo.png" img-fluid rounded-start iconessociais" alt="Icone do GitHub"></a>
        </div>




      </div>

      <div class="row mt-3 ">
        <div class="col-md-12 text-white" style="justify-content: center;">
          <p style="text-align: center;">&copy; 2023 - Todos os direitos reservados</p>
          <p style="text-align: center;">Entre em contato pelo e-mail: contato@exemplo.com</p>
        </div>

      </div>
    </div>

    </div>
    <br>
    <br>

  </footer>
  <script src="lib/owlCarousel/dist/owl.carousel.min.js"></script>
  <script src="lib/jQuery/jquery.min.js"></script>
  <script src="script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>

</html>