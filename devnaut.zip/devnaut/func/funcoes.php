<?php
function listarTabela($campos, $tabela, $campoOrdem)
{
    $conn = conectar();
    try {
        $conn->beginTransaction();
        $sqlLista = $conn->prepare("SELECT $campos FROM $tabela ORDER BY $campoOrdem");
        $sqlLista->execute();
        $conn->commit();
        
        if ($sqlLista->rowCount() > 0) {
            return $sqlLista->fetchAll(PDO::FETCH_OBJ);
        } else {
            return 'Vazio';
        }
    } catch (PDOException $e) {
        $conn->rollback();
        echo 'Exception -> ';
        return ($e->getMessage());
    }
    $conn = null;
};



function validarSenhaCriptografia($campos, $tabela, $campoBdString, $campoBdString2, $campoParametro, $campoParametro2)
{
    $conn = conectar();
    try {
        $conn->beginTransaction();
        $sqlLista = $conn->prepare("SELECT $campos "
            . "FROM $tabela "
            . "WHERE $campoBdString = ?");
        $sqlLista->bindValue(1, $campoParametro, PDO::PARAM_STR);
        //$sqlLista->bindValue(2, $valorAtivo, PDO::PARAM_STR);
        $sqlLista->execute();
        $conn->commit();
        if ($sqlLista->rowCount() > 0) {
            $retornoSql = $sqlLista->fetch(PDO::FETCH_OBJ);
            $senhaHash = $retornoSql->$campoBdString2;
            if (password_verify($campoParametro2, $senhaHash)) {
                return $retornoSql;
            }
            return 'senha';
        } else {
            return 'usuario';
        }
        return null;
    } catch (Throwable $e) {
        $error_message = 'Throwable:' . $e->getMessage() . PHP_EOL;
        $error_message = 'File:' . $e->getFile() . PHP_EOL;
        $error_message = 'Line:' . $e->getLine() . PHP_EOL;
        error_log($error_message, 3, 'log/arquivo_log.txt');
        $conn->rollBack();
        throw $e;
    };
}




function insert($tabela, $campo, $value1){
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campo) VALUES(?)");
        $sqlInsert->bindValue(1, $value1, PDO::PARAM_STR);
        $sqlInsert->execute();
        $conn->commit();
        if ($sqlInsert->rowCount() > 0){
            return true;
        } else {
            return null;;
        };
    } 
    catch(PDOException $e) {
        echo 'Exeception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
  };

  function editum($tabela, $campo, $campoId, $valorupdate, $valorid){
    $conn = conectar();
    try {
        $conn ->beginTransaction();
        $sqlLista = $conn->prepare("UPDATE $tabela SET $campo = ? WHERE $campoId = ?");
        $sqlLista->bindValue(1, $valorupdate, PDO::PARAM_STR);
        $sqlLista->bindValue(2, $valorid, PDO::PARAM_INT);
        $sqlLista->execute();
        $conn->commit();
        if ($sqlLista->rowCount() > 0) {
            return 1;
        } else {
            return true;
        }
        return null;

    } catch (Throwable $e) {
       
    };

};

function excluir($tabela, $campo, $id){
    $conn = conectar();
    try {
        $conn ->beginTransaction();
        $sqlExcluir = $conn->prepare("DELETE FROM $tabela WHERE $campo = ?");
        $sqlExcluir->bindValue(1, $id, PDO::PARAM_STR);
        $sqlExcluir->execute();
        $conn->commit();

        if ($sqlExcluir->rowCount() > 0) {
            return true;
        } else {
            return null;
        }
        

    } catch (PDOException $e) {
        echo 'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
       
    }
    $conn=null;
};

function insertdois($tabela, $campo1, $campo2, $value1, $value2){
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campo1,$campo2) VALUES(?,?)");
        $sqlInsert->bindValue(1, $value1, PDO::PARAM_STR);
        $sqlInsert->bindValue(2, $value2, PDO::PARAM_STR);
        $sqlInsert->execute();
        $conn->commit();
        if ($sqlInsert->rowCount() > 0){
            return true;
        } else {
            return null;;
        };
    } 
    catch(PDOException $e) {
        echo 'Exeception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
};

function buscarproduto($idProduto)
{
    $conn = conectar();
    try {
        $conn->beginTransaction();
        $sql = $conn->prepare("SELECT idproduto, nome, foto, detalhes, valor FROM produto WHERE idproduto = ?");
        $sql->bindValue(1, $idProduto, PDO::PARAM_INT);
        $sql->execute();
        $conn->commit();
        $produto = $sql->fetch(PDO::FETCH_OBJ);
        if ($produto) {
            return $produto;
        } else {
            return null;
        }
    } catch (PDOException $e) {
        echo 'Exception -> ';
        return $e->getMessage();
        $conn->rollback();
    }
    $conn = null;
};



function insertpaga($tabela, $campos, $valores, $parametros = []) {
    $conn = conectar();
    try {
        $conn->beginTransaction();

   
        $sql = "INSERT INTO $tabela ($campos) VALUES ($valores)";
        $stmt = $conn->prepare($sql);

      
        foreach ($parametros as $placeholder => $valor) {
            $stmt->bindValue(":$placeholder", $valor);
        }

     
        $stmt->execute();

        $conn->commit();

      
        if ($stmt->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    } catch(PDOException $e) {
     
        echo 'Exception -> ';
        echo $e->getMessage();
        $conn->rollBack();
        return false;
    } finally {
      
        $conn = null;
    }
};





function buscarcliente($numeroCartao) {
    $conn = conectar();
    
    try {
       
        $sql = "SELECT idcliente FROM cliente WHERE codigo = :numeroCartao";
        $stmt = $conn->prepare($sql);
   
        $stmt->bindParam(':numeroCartao', $numeroCartao);
        
   
        $stmt->execute();
        
 
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        
      
        if ($resultado && isset($resultado['idcliente'])) {
            return $resultado['idcliente'];
        } else {
            return null; 
        }
    } catch(PDOException $e) {
        echo 'Exception -> ';
        echo $e->getMessage();
        return null; 
    } finally {
     
        $conn = null;
    }
};


function insertSeisid($tabela, $campos, $valeu1, $valeu2, $valeu3, $valeu4, $valeu5, $valeu6) {
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campos) VALUES (?,?,?,?,?,?)");
        $sqlInsert ->bindValue(1, $valeu1, PDO::PARAM_STR);
        $sqlInsert ->bindValue(2, $valeu2, PDO::PARAM_STR);
        $sqlInsert ->bindValue(3, $valeu3, PDO::PARAM_STR);
        $sqlInsert ->bindValue(4, $valeu4, PDO::PARAM_STR);
        $sqlInsert ->bindValue(5, $valeu5, PDO::PARAM_STR);
        $sqlInsert ->bindValue(6, $valeu6, PDO::PARAM_STR);
        $sqlInsert ->execute();
        $IdInsertRetorno = $conn -> lastInsertId();
        $conn->commit();

        if ($sqlInsert->rowCount() > 0) {
            return $IdInsertRetorno;
        }else {
            return 'nGravado';
        };
    }catch
    (PDOException $e) {
        echo 'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
};


function insertCincoId($tabela, $campos, $valeu1, $valeu2, $valeu3, $valeu4, $valeu5) {
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campos) VALUES (?,?,?,?,?)");
        $sqlInsert ->bindValue(1, $valeu1, PDO::PARAM_STR);
        $sqlInsert ->bindValue(2, $valeu2, PDO::PARAM_STR);
        $sqlInsert ->bindValue(3, $valeu3, PDO::PARAM_STR);
        $sqlInsert ->bindValue(4, $valeu4, PDO::PARAM_STR);
        $sqlInsert ->bindValue(5, $valeu5, PDO::PARAM_STR);
        $sqlInsert ->execute();
        $IdInsertRetorno = $conn -> lastInsertId();
        $conn->commit();

        if ($sqlInsert->rowCount() > 0) {
            return $IdInsertRetorno;
        }else {
            return 'nGravado';
        };
    }catch
    (PDOException $e) {
        echo 'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
};


function updateum($tabela, $campobd, $campobdId, $valorReceberinput, $inputvalorinvisivel) {
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlUpdate = $conn->prepare("UPDATE $tabela SET $campobd = ? WHERE $campobdId = ? "  );
        $sqlUpdate ->bindValue(1, $valorReceberinput, PDO::PARAM_STR);
        $sqlUpdate ->bindValue(2, $inputvalorinvisivel, PDO::PARAM_INT);
        $sqlUpdate ->execute();
        $conn->commit();

        if ($sqlUpdate->rowCount() > 0) {
            return 1;
        }else {
            return null;
        }
        
        return null;
    }catch
    (Throwable $e) {
      
    };
   
};



function deletar2($tabela, $campoReferencia, $idparametro){
    $conn=conectar();
    try{
        $conn->beginTransaction();
        $sqlUpdate = $conn->prepare("DELETE FROM $tabela WHERE $campoReferencia = ?");
        $sqlUpdate ->bindValue(1, $idparametro, PDO::PARAM_INT);
        $sqlUpdate ->execute();
        $conn->commit();

        if ($sqlUpdate->rowCount() > 0) {
            return true;
        }else {
            return null;
        };
        
    
    }catch
    (PDOException $e) {
        echo 'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
   
    $conn = null;

};



function deletarRegistro($tabela, $campoReferencia, $idparametro)
{
    $conn = conectar();
    try {
        $conn->beginTransaction();
        $sqlUpdate = $conn->prepare("DELETE FROM $tabela WHERE $campoReferencia = ? ");
        $sqlUpdate->bindValue(1, $idparametro, PDO::PARAM_INT);
        $sqlUpdate->execute();
        $conn->commit();
        if ($sqlUpdate->rowCount() > 0) {
            return true;
        } else {
            return null;
        };

    }catch
    (PDOException $e) {
        echo'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
};



function insertclienteid($tabela, $campos, $valeu1, $valeu2, $valeu3) {
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campos) VALUES (?,?,?)");
        $sqlInsert ->bindValue(1, $valeu1, PDO::PARAM_STR);
        $sqlInsert ->bindValue(2, $valeu2, PDO::PARAM_STR);
        $sqlInsert ->bindValue(3, $valeu3, PDO::PARAM_STR);
        $sqlInsert ->execute();
        $IdInsertRetorno = $conn -> lastInsertId();
        $conn->commit();

        if ($sqlInsert->rowCount() > 0) {
            return $IdInsertRetorno;
        }else {
            return 'nGravado';
        };
    }catch
    (PDOException $e) {
        echo 'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
};



function updatecliente($tabela, $campobd, $campobd2, $campobd3, $campobdId, $valorReceberinput, $valorReceberinput2, $valorReceberinput3, $inputvalorinvisivel) {
    $conn = conectar();
    try {
        $conn->beginTransaction();
        $sqlUpdate = $conn->prepare("UPDATE $tabela SET $campobd = ?, $campobd2 = ?, $campobd3 = ? WHERE $campobdId = ?");
        $sqlUpdate->bindValue(1, $valorReceberinput, PDO::PARAM_STR);
        $sqlUpdate->bindValue(2, $valorReceberinput2, PDO::PARAM_STR);
        $sqlUpdate->bindValue(3, $valorReceberinput3, PDO::PARAM_STR);
        $sqlUpdate->bindValue(4, $inputvalorinvisivel, PDO::PARAM_INT);
        $sqlUpdate->execute();
        $conn->commit();

        if ($sqlUpdate->rowCount() > 0) {
            return 1;
        } else {
            return null;
        }
    } catch (Throwable $e) {
        $conn->rollBack();
        return null; // Retorna null em caso de exceção
    }
};


function insertCarro($tabela, $campos, $valeu1, $valeu2, $valeu3, $valeu4) {
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campos) VALUES (?,?,?,?)");
        $sqlInsert ->bindValue(1, $valeu1, PDO::PARAM_STR);
        $sqlInsert ->bindValue(2, $valeu2, PDO::PARAM_STR);
        $sqlInsert ->bindValue(3, $valeu3, PDO::PARAM_STR);
        $sqlInsert ->bindValue(4, $valeu4, PDO::PARAM_STR);
        $sqlInsert ->execute();
        $IdInsertRetorno = $conn -> lastInsertId();
        $conn->commit();

        if ($sqlInsert->rowCount() > 0) {
            return $IdInsertRetorno;
        }else {
            return 'nGravado';
        };
    }catch
    (PDOException $e) {
        echo 'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
};




function updatecarro($tabela, $campobdidproprie, $campobdnome, $campobdfoto, $campobddetalhes, $campovalor, $campobdId, $valorReceberinputidproprie, $valorReceberinputnome, $valorReceberinputfoto, $valorReceberinputdet, $valorReceberinputvalor, $inputvalorinvisivel) {
    $conn = conectar();
    try {
        $conn->beginTransaction();
        $sqlUpdate = $conn->prepare("UPDATE $tabela SET $campobdidproprie = ?, $campobdnome = ?, $campobdfoto = ?, $campobddetalhes = ?, $campovalor = ? WHERE $campobdId = ?");
        $sqlUpdate->bindValue(1, $valorReceberinputidproprie, PDO::PARAM_STR);
        $sqlUpdate->bindValue(2, $valorReceberinputnome, PDO::PARAM_STR);
        $sqlUpdate->bindValue(3, $valorReceberinputfoto, PDO::PARAM_STR);
        $sqlUpdate->bindValue(4, $valorReceberinputdet, PDO::PARAM_STR);
        $sqlUpdate->bindValue(5, $valorReceberinputvalor, PDO::PARAM_STR);
        $sqlUpdate->bindValue(6, $inputvalorinvisivel, PDO::PARAM_INT);
        $sqlUpdate->execute();
        $conn->commit();

        if ($sqlUpdate->rowCount() > 0) {
            return 1;
        } else {
            return null;
        }
    } catch (Throwable $e) {
        $conn->rollBack();
        return null; // Retorna null em caso de exceção
    }
};



function atualizarSaldoCliente($conn, $codigoCartao, $valorCompra) {
    try {
        $conn->beginTransaction();
        
        // Verificar se o código do cartão é válido e obter o saldo do cliente
        $sql = "SELECT idcliente, saldo FROM cliente WHERE codigo = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$codigoCartao]);
        $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$cliente) {
            throw new Exception("Código de cartão inválido.");
        }
        
        $clienteId = $cliente['idcliente'];
        $saldoAtual = (float)$cliente['saldo'];
        
        // Verificar se há saldo suficiente para a compra
        if ($saldoAtual < $valorCompra) {
            throw new Exception("Saldo insuficiente para realizar a compra.");
        }
        
        // Atualizar o saldo do cliente
        $novoSaldo = $saldoAtual - $valorCompra;
        $sqlUpdate = "UPDATE cliente SET saldo = ? WHERE idcliente = ?";
        $stmtUpdate = $conn->prepare($sqlUpdate);
        $stmtUpdate->execute([$novoSaldo, $clienteId]);
        
        $conn->commit();
        
        return true; // Transação bem-sucedida
    } catch (Exception $e) {
        $conn->rollback();
        throw $e; // Retornar exceção para tratamento adequado
    }
};










function deletar($tabela, $campo, $idparametro)
{


    $conn = conectar();

    try {
        $conn->beginTransaction();

        $delete = $conn->prepare("DELETE FROM $tabela WHERE $campo = ? ");
        $delete->bindValue(1, $idparametro, PDO:: PARAM_INT);

        $delete->execute();
        $conn->commit();
        if ($delete->rowCount() > 0) {
            return 1;
        } else {
            return null;
        };
        return null;

    } catch (throwable $e) {

    };
}







?>
