<div class="container mt-3">

    <div class='row'>
        <div class='col-md-10 mt-3 '>
            <h3 class='text-center'>Contato</h3>
        </div>
       
    </div>


    <table class="table table-striped table-hover ">

        <thead>
            <tr class="me-3">
                <th scope="col" style="width: 10%;">#</th>
                <th scope="col" style="width: 30%;">Nome</th>
                <th scope="col" style="width: 30%;">Numero</th>
                <th scope="col" style="width: 30%;">email</th>
            </tr>
        </thead>


            <?php
            $retornocont = listarTabela('idcontato, idusuario, nome, numero', 'contato', 'idcontato');
            if ($retornocont != 'Vazio') {
                foreach ($retornocont as $cont) {
                    $idcontato = $cont->idcontato;
                    $idcontatous = $cont->idusuario;
                    $nome = $cont->nome;
                    $numero = $cont->numero;

                    $retornousuario = listarTabela('idusuario, email', 'usuario', 'idusuario');
                    if ($retornousuario != 'Vazio') {
                        foreach ($retornousuario as $usuario) {
                            $idusuario = $usuario->idusuario;
                            $emal = $usuario->email;

                            if ($idusuario == $idcontatous){
                                ?>
                                


  
        <tbody>

            <td><?php echo $idcontato ?></td>
            <td><?php echo $nome ?></td>
            <td><?php echo $numero ?></td>
            <td><?php echo $emal ?></td>

           
    <?php
                }}}}
            };
    ?>
        </tbody>
    </table>

</div>
</div>