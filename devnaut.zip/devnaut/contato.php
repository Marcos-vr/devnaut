<div class="container mt-3">

    <div class='row'>
        <div class='col-md-10 mt-3 '>
            <h3 class='text-center'>Contato</h3>
        </div>

    </div>


    <table class="table table-striped table-hover ">

        <thead>
            <tr class="me-3">
                <th scope="col" style="width: 10%;">#</th>
                <th scope="col" style="width: 30%;">Nome</th>
                <th scope="col" style="width: 30%;">Numero</th>
            </tr>
        </thead>


        <?php
        $retornocont = listarTabela('idcontanto, nome, numero', 'contanto', 'idcontanto');

        // Verifica se $retornocont não é uma string e se não está vazio
        if (!is_string($retornocont) && (is_array($retornocont) || is_object($retornocont))) {
            foreach ($retornocont as $cont) {
                $idcontato = $cont->idcontanto;
                $nome = $cont->nome;
                $telefone = $cont->numero;
                ?>

                <tr>
                    <td><?php echo $idcontato ?></td>
                    <td><?php echo $nome ?></td>
                    <td><?php echo $telefone ?></td>
                </tr>

                <?php
            }
        } else {
            // Não há registros retornados, exibe uma mensagem adequada
            echo "<tr><td colspan='3'>Não há registros de contatos.</td></tr>";
        }
        ?>
                </tbody>
    </table>

</div>
</div>