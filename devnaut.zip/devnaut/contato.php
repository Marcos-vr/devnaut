<div class="container mt-3">

    <div class='row'>
        <div class='col-md-10 mt-3 '>
            <h3 class='text-center'>Contato</h3>
        </div>

    </div>


    <table class="table table-striped table-hover ">

        <thead>
            <tr class="me-3">
                <th scope="col" style="width: 10%;">#</th>
                <th scope="col" style="width: 30%;">Nome</th>
                <th scope="col" style="width: 30%;">Numero</th>
            </tr>
        </thead>


        <?php
        $retornocont = listarTabela('idcontato, nome, telefone', 'contato', 'idcontato');
        if ($retornocont != 'Vazio') {
            foreach ($retornocont as $cont) {
                $idcontato = $cont->idcontato;
                $nome = $cont->nome;
                $telefone = $cont->telefone;




        ?>
                <tbody>

                    <td><?php echo $idcontato ?></td>
                    <td><?php echo $nome ?></td>
                    <td><?php echo $telefone ?></td>



            <?php
            }
        };
            ?>
                </tbody>
    </table>

</div>
</div>