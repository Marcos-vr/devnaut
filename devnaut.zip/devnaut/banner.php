<div class="container mt-3">

    <div class='row'>
        <div class='col-md-10 mt-3 '>
            <h3 class='text-center'>Banner</h3>
        </div>
        <div class='col-md-2 '><button class="btn btn-outline-primary  btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#modalAddBanner" style='float: right'><i class="bi bi-person-plus"></i> Cadastrar</button></div>
    </div>


    <table class="table table-striped table-hover ">

        <thead>
            <tr class="me-3">
                <th scope="col" style="width: 10%;">#</th>
                <th scope="col" style="width: 30%;">Foto</th>
                <th scope="col" style="width: 30%;">Nome</th>
                <th scope="col" style="width: 30%;">Ação</th>
            </tr>
        </thead>


        <?php
        $retornobanner = listarTabela('idbanner, foto, nome', 'banner', 'idbanner');
        if ($retornobanner != 'Vazio') {
            foreach ($retornobanner as $banner) {
                $idbanner = $banner->idbanner;
                $foto = $banner->foto;
                $nome = $banner->nome;


        ?>

                <tbody>

                    <td><?php echo $idbanner ?></td>
                    <td><img src="img/<?php echo $foto ?>" alt="" srcset="" width="90%"></td>
                    <td><?php echo $nome ?></td>

                    <th>
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-outline-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalAltBanner" onclick="abrirModalEdicao3('<?php echo $nome ?>', <?php echo $idbanner ?>)"><i class="bi bi-upload"></i> Alterar</button>

                            <button type="button" class="btn btn-outline-danger btn-sm" onclick="deletarBanner('excluirBanner',<?php echo $idbanner ?>, 'listarbanner')"> <i class="bi bi-trash"></i></button>
                        </div>
                    </th>
            <?php
            }
        };
            ?>
                </tbody>
    </table>

</div>
</div>