<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//echo json_encode($dados);

if (!empty($dados) && isset($dados)) {


    $nome = $dados["textoNomes"];
    $tipo = $dados["tipoAdds"];


    $retornoInsert = insert2d('texto', 'nome , tipo', "$nome", "$tipo", "$idtexto");

    //    echo json_encode($retornoInsert);
    if ($retornoInsert > 0) {
        echo json_encode(['success' => true, 'message' => "Texto cadastro com sucesso"]);
    } else {
        echo json_encode(['success' => false, 'message' => "Genero nao cadastrado! Error Bd"]);
    }
} else {
    echo json_encode(['success' => false, 'message' => "Genero nao cadastrado! Error variavel"]);
};
