<?php
include_once("config/conexao.php");
include_once("config/constantes.php");
include_once("func/funcoes.php");
if (isset($_SESSION['idusuario'])) {
  $id = $_SESSION['idusuario'];
  $nome = $_SESSION['nome'];
  $email = $_SESSION['email'];
  $adm = $_SESSION['adm'];
}
$options = [
  'cost' => 12
];
$conn = conectar();
if (isset($_POST['impnomecad'])) { // Registro no site
  $impnome = $_POST['impnomecad'];
  $impemail = $_POST['impemailcad'];
  $impsenha = $_POST['impsenhacad'];
  $hashPass = password_hash($impsenha, PASSWORD_BCRYPT, $options);
  $register = "INSERT INTO adm (nome, email, senha ) VALUES (:impnome, :impemail, :impsenha)";
  $insert = $conn->prepare($register);
  $insert->bindParam(':impnome', $impnome);
  $insert->bindParam(':impemail', $impemail);
  $insert->bindParam(':impsenha', $hashPass);
  $conn->beginTransaction();
  $insert->execute();
  $conn->commit();
  header("Location: testelogin.php");
}
