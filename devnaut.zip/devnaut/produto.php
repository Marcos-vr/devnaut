<div class="container mt-3">

    <div class='row'>
        <div class='col-md-10 mt-3 '>
            <h3 class='text-center'>Jogos</h3>
        </div>
        <div class='col-md-2 '><button class="btn btn-outline-primary  btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#modalAddProduto" data-bs-toggle="modal" data-bs-target="#staticBackdrop" style='float: right'><i class="bi bi-person-plus"></i> Cadastrar</button></div>
    </div>


    <table class="table table-striped table-hover ">

        <thead>
            <tr class="me-3">
                <th scope="col" style="width: 5%;">#</th>
                <th scope="col" style="width: 15%;">Foto</th>
                <th scope="col" style="width: 18%;">Nome</th>
                <th scope="col" style="width: 25%;">Detalhes</th>
                <th scope="col" style="width: 17%;">Lançamento</th>
                <th scope="col" style="width: 17%;">Tipo</th>
                <th scope="col" style="width: 20%;">Ação</th>
            </tr>
        </thead>


        <?php
        $retornojogos = listarTabela('idjogos, nome, detalhes, Lancamento, foto, tipo', 'jogos', 'idjogos');
        if ($retornojogos != 'Vazio') {
            foreach ($retornojogos as $jogo) {
                $idjogos = $jogo->idjogos;
                $nome = $jogo->nome;
                $detalhes = $jogo->detalhes;
                $Lancamento = $jogo->Lancamento;
                $foto = $jogo->foto;
                $tipo = $jogo->tipo;

              

        ?>

                <tbody>

                    <td><?php echo $idjogos ?></td>
                    <td><img style="width: 100px;" src="./img/<?php echo $foto ?>" alt="" class="img-fluid" data-bs-toggle="modal" data-bs-target="#detalhe"></td>

                    <td><?php echo $nome ?></td>
                    <td><?php echo $detalhes ?></td>
                    <td><?php echo $Lancamento ?></td>
                    <td><?php echo $tipo ?></td>

                    <th>
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-outline-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalAltProduto" onclick="abrirModalEdicao2('<?php echo $nome ?>','<?php echo $detalhes ?>','<?php echo $Lancamento ?>','<?php echo $tipo ?>',<?php echo $idjogos ?>)"><i class="bi bi-upload"></i> Alterar</button>


                            <button type="button" class="btn btn-outline-danger btn-sm" onclick="deletar2('excluirProduto',<?php echo $idjogos ?>, 'listarproduto')" id="butau"> <i class="bi bi-trash">Excluir</i></button>
                        </div>
                    </th>
            <?php
            }
        };
            ?>
                </tbody>
    </table>

</div>
</div>