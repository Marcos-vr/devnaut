Esta página informa você sobre nossas políticas referentes à coleta, uso e divulgação de dados pessoais quando você usa nosso Serviço e sobre as escolhas que você possui associadas a esses dados.

Nós usamos seus dados para fornecer e melhorar o Serviço. Ao utilizar o Serviço, você concorda com a coleta e uso de informações de acordo com esta política. A menos que definido de outra forma nesta Política de Privacidade, os termos utilizados nesta Política de Privacidade têm os mesmos significados que em nossos Termos e Condições, acessíveis no [SeuSite.com].

Coleta e Uso de Informações

Nós coletamos vários tipos diferentes de informações para diversos fins, para fornecer e melhorar nosso Serviço para você.

Tipos de Dados Coletados

Dados Pessoais: Ao usar nosso Serviço, podemos solicitar que você nos forneça certas informações pessoalmente identificáveis que podem ser usadas para contatá-lo ou identificá-lo ("Dados Pessoais"). As informações pessoalmente identificáveis podem incluir, mas não estão limitadas a:
Endereço de e-mail
Nome e sobrenome
Número de telefone
Endereço
Cookies e Dados de Uso
Uso de Dados

[Seu Nome/Empresa] utiliza os dados coletados para diversos fins:

Para fornecer e manter nosso Serviço
Para notificá-lo sobre alterações em nosso Serviço
Para permitir que você participe de recursos interativos do nosso Serviço quando você optar por fazê-lo
Para fornecer atendimento e suporte ao cliente
Para fornecer análises ou informações valiosas para que possamos melhorar nosso Serviço
Para monitorar o uso do Serviço
Para detectar, prevenir e resolver problemas técnicos
Transferência de Dados

Suas informações, incluindo Dados Pessoais, podem ser transferidas para — e mantidas em — computadores localizados fora do seu estado, província, país ou outra jurisdição governamental onde as leis de proteção de dados podem diferir das de sua jurisdição.

Se você estiver localizado fora do Brasil e optar por nos fornecer informações, por favor, note que nós transferimos os dados, incluindo Dados Pessoais, para o Brasil e os processamos lá.

Seu consentimento para esta Política de Privacidade, seguido por seu envio de tais informações, representa sua concordância com essa transferência.

[Seu Nome/Empresa] tomará todas as medidas razoavelmente necessárias para garantir que seus dados sejam tratados de forma segura e de acordo com esta Política de Privacidade e nenhuma transferência de seus Dados Pessoais ocorrerá para uma organização ou país, a menos que haja controles adequados em vigor, incluindo a segurança dos seus dados e outras informações pessoais.

Divulgação de Dados

Requisitos legais

[Seu Nome/Empresa] pode divulgar seus Dados Pessoais sob acreditar de boa-fé que tal ação é necessária para:

Cumprir uma obrigação legal
Proteger e defender os direitos ou propriedade de [Seu Nome/Empresa]
Prevenir ou investigar possíveis irregularidades em relação ao Serviço
Proteger a segurança pessoal dos usuários do Serviço ou do público
Proteger contra responsabilidade legal
Segurança de Dados

A segurança dos seus dados é importante para nós, mas lembre-se de que nenhum método de transmissão pela internet ou método de armazenamento eletrônico é 100% seguro. Enquanto nos esforçamos para usar meios comercialmente aceitáveis para proteger seus Dados Pessoais, não podemos garantir sua segurança absoluta.

Links para Outros Sites

Nosso Serviço pode conter links para outros sites que não são operados por nós. Se você clicar em um link de terceiros, você será direcionado para o site desse terceiro. Nós recomendamos fortemente que você reveja a Política de Privacidade de todos os sites que você visita.

Privacidade das Crianças

Nosso Serviço não se dirige a ninguém com menos de 18 anos ("Crianças").

Nós não coletamos intencionalmente informações pessoalmente identificáveis de menores de 18 anos. Se você é pai ou mãe ou responsável legal e está ciente de que seu filho nos forneceu Dados Pessoais, por favor, entre em contato conosco. Se nós tomarmos conhecimento de que coletamos Dados Pessoais de crianças sem verificação do consentimento dos pais, nós tomaremos medidas para remover essas informações de nossos servidores.

Alterações a esta Política de Privacidade

Podemos atualizar nossa Política de Privacidade de tempos em tempos. Nós iremos notificá-lo de quaisquer alterações publicando a nova Política de Privacidade nesta página.

Nós iremos notificá-lo por e-mail e/ou um aviso em destaque em nosso Serviço, antes que a alteração entre em vigor, e atualizaremos a "data efetiva" na parte superior desta Política de Privacidade.

Você é aconselhado a revisar esta Política de Privacidade periodicamente para quaisquer alterações. Alterações a esta Política de Privacidade são efetivas quando são publicadas nesta página.

Contate-Nos

Se você tiver alguma dúvida sobre esta Política de Privacidade, por favor, entre em contato conosco:

Por e-mail: [Seu e-mail]
Visitando esta página no nosso website: [SeuSite.com/contato]