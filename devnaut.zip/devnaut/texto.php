<div class="container mt-3">

    <div class='row'>
        <div class='col-md-10 mt-3 '>
            <h3 class='text-center'>Texto</h3>
        </div>
        <div class='col-md-2 '><button class="btn btn-outline-primary  btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop" style='float: right'><i class="bi bi-person-plus"></i> Cadastrar</button></div>
    </div>


    <table class="table table-striped table-hover ">

        <thead>
            <tr class="me-3">
                <th scope="col" style="width: 10%;">#</th>
                <th scope="col" style="width: 30%;">texto</th>
                <th scope="col" style="width: 30%;">tipo</th>
                <th scope="col" style="width: 30%;">Ação</th>
              
        </thead>


            <?php
            $retornotexto = listarTabela('idtexto, nome, tipo', 'texto', 'idtexto');
            if ($retornotexto != 'Vazio') {
                foreach ($retornotexto as $banner) {
                    $idtexto = $banner->idtexto;
                    $nome = $banner->nome;
                    $tipo = $banner->tipo;
                  

            ?>
  
        <tbody>

            <td><?php echo $idtexto ?></td>
            <td><?php echo $nome ?></td>
            <td><?php echo $tipo ?></td>

            <th>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button type="button" class="btn btn-outline-primary btn-sm">Ver<i class="bi bi-plus-lg"></i></button>
                    <button type="button" class="btn btn-outline-warning btn-sm"><i class="bi bi-upload"></i> Alterar</button>

                    <button type="button" class="btn btn-outline-danger btn-sm" onclick="deletar('excluirAdm',<?php echo $idadm?>)"> <i class="bi bi-trash"></i></button>
                </div>
            </th>
    <?php
                }
            };
    ?>
        </tbody>
    </table>

</div>
</div>