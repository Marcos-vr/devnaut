<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/login.css">
    <title>Login ADM</title>
   
</head>
<body>

<div class="main-login">
    <div class="left-login">
        <h1>Faça Login<br> E entre para o nosso time </h1>
        <h1>Faça Login<br> E entre para o nosso time </h1>
    </div>
    <div class="right-login">
        <div class="card-login">
        <div class="textfield">
            <label for="usuario">Usuário</label>
            <input type="text" name="usuario " placeholder="Usuário">
        </div>
        <div class="textfield">
            <label for="senha">Usuário</label>
            <input type="password" name="senha " placeholder="Senha">
            <button class="btn-login">Login</button>
        </div>
        </div>
    </div>
</div>


   
</body>

</html>