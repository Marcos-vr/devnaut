<div class="container mt-3">

    <div class='row'>
        <div class='col-md-10 mt-3 '>
            <h3 class='text-center'>Administrador</h3>
        </div>
        <div class='col-md-2 '><button class="btn btn-outline-primary  btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop" style='float: right'><i class="bi bi-person-plus"></i> Cadastrar</button></div>
    </div>


    <table class="table table-striped table-hover ">

        <thead>
            <tr class="me-3">
                <th scope="col" style="width: 10%;">#</th>
                <th scope="col" style="width: 30%;">Nome</th>
                <th scope="col" style="width: 30%;">Email</th>
                <th scope="col" style="width: 30%;">Açao</th>
            </tr>
        </thead>


            <?php
            $retornoadm = listarTabela('idadm, nome, email, senha', 'adm', 'idadm');
            if ($retornoadm != 'Vazio') {
                foreach ($retornoadm as $adms) {
                    $idadm = $adms->idadm;
                    $nome = $adms->nome;
                    $email = $adms->email;


            ?>
  
        <tbody>

            <td><?php echo $idadm ?></td>
            <td><?php echo $nome ?></td>
            <td><?php echo $email ?></td>

            <th>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button type="button" class="btn btn-outline-primary btn-sm">Ver<i class="bi bi-plus-lg"></i></button>
                    <button type="button" class="btn btn-outline-warning btn-sm"><i class="bi bi-upload"></i> Alterar</button>

                    <button type="button" class="btn btn-outline-danger btn-sm" onclick="deletar('excluirAdm',<?php echo $idadm?>)"> <i class="bi bi-trash"></i></button>
                </div>
            </th>
    <?php
                }
            };
    ?>
        </tbody>
    </table>

</div>
</div>