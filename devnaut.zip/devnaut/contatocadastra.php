<?php
include_once "./config/conexao.php";
include_once "./config/constantes.php";
include_once "./func/funcoes.php" ;

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
if (isset($dados) && !empty($dados)) {

    $nome = isset($dados['nomeContato']) ? addslashes($dados['nomeContato']) : '';
    $telefone = isset($dados['numeroContato']) ? addslashes($dados['numeroContato']) : '';

    $retornoInserts = insert2('contanto', 'nome', 'numero', $nome, $telefone);

    if ($retornoInserts === true) {
        echo json_encode(['success' => true, 'message' => "Olá $nome, aguarde nosso contato."], JSON_THROW_ON_ERROR);
    } else {
        echo json_encode(['success' => false, 'message' => "Contato não cadastrado! Erro BD: $retornoInserts"], JSON_THROW_ON_ERROR);
    }
} else {
    echo json_encode(['success' => false, 'message' => "Contato não cadastrado! Erro de variável."], JSON_THROW_ON_ERROR);
}
header("Location: index.php");
?>