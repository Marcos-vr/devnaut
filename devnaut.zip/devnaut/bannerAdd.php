<?php

include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//echo json_encode($dados)


$nome = $dados["inNomeBanner"] ;
$foto = $dados["inFotoBanner"] ;



if (isset($_FILES['foto'])&& $_FILES['foto']['error']==UPLOAD_ERR_OK ){
    $fotoTmpNome = $_FILES['foto']['tmp_name'];
    $fotoName = $_FILES['foto']['name'];
    $uploadDir = 'img';
    $fotoPath = uniqid().'_'.$fotoName;
    if (move_uploaded_file($fotoTmpNome,$uploadDir.'/'.$fotoPath)){



    $retornoInsert = insertbanner('banner', 'foto , nome', "$fotoPath", "$nome",DATATIMEATUAL);

   //echo json_encode($retornoInsert);
    if ($retornoInsert > 0) {
        echo json_encode(['success' => true, 'message' => "Banner cadastro com sucesso"]);

    }else {
        echo json_encode(['success' => false, 'message' => "Banner nao cadastrado! Error Bd"]);
    }
}else {
    echo json_encode(['success' => false, 'message' => "Banner nao cadastrado! Error variavel"]);
 }
 };

?>
