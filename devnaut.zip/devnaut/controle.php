<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

$controle = filter_input(INPUT_POST, 'controle', FILTER_SANITIZE_STRING);

if (isset($controle) && !empty('controle')) {
    switch ($controle) {
        case 'listarAdministrador';
            include_once 'adm.php';
            break;
        case 'excluirAdm';
            include_once 'excluirAdm.php';
            break;

        case 'listarcontato';
            include_once 'contato.php';
            break;

        case 'listarbanner';
            include_once 'banner.php';
            break;

        case 'listarproduto';
            include_once 'produto.php';
            break;

        case 'listartexto';
            include_once 'texto.php';
            break;

        case 'produtoadd';
            include_once 'produtoadd.php';
            break;

        case 'bannerAdd';
            include_once 'bannerAdd.php';
            break;

        case ' produtoalt';
            include_once 'produtoalt.php';
            break;

        case 'excluirProduto';
            include_once 'excluirproduto.php';
            break;

        case 'excluirBanner';
            include_once 'excluirBanner.php';
            break;
        default:
            echo 'Pagina nao encontrada';
    }
}
