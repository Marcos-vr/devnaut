Seu acesso e uso do Serviço estão condicionados à sua aceitação e conformidade com estes Termos. Estes Termos se aplicam a todos os visitantes, usuários e outras pessoas que acessam ou usam o Serviço.

Ao acessar ou usar o Serviço, você concorda em ficar vinculado por estes Termos. Se você discordar de qualquer parte dos termos, então você não tem permissão para acessar o Serviço.

Contas

Ao criar uma conta conosco, você deve fornecer informações precisas, completas e atualizadas. Falha em fazer isso constituirá uma violação dos Termos, o que pode resultar no encerramento imediato da sua conta em nosso Serviço.

Você é responsável por proteger a senha que você usa para acessar o Serviço e por quaisquer atividades ou ações sob sua senha, seja sua senha com o nosso Serviço ou um serviço de terceiros.

Você concorda em não divulgar sua senha a terceiros. Você deve nos notificar imediatamente após tomar conhecimento de qualquer violação de segurança ou uso não autorizado de sua conta.

Links para Outros Sites

Nosso Serviço pode conter links para sites de terceiros ou serviços que não são de propriedade ou controlados por [Nome da Sua Empresa].

[Nome da Sua Empresa] não tem controle e não assume responsabilidade pelo conteúdo, políticas de privacidade ou práticas de quaisquer sites ou serviços de terceiros. Você reconhece e concorda que [Nome da Sua Empresa] não será responsável, direta ou indiretamente, por qualquer dano ou perda causada ou alegadamente causada por ou em conexão com o uso ou dependência de qualquer conteúdo, bens ou serviços disponíveis em ou através de tais sites ou serviços.

Recomendamos que você leia os termos e condições e políticas de privacidade de qualquer site ou serviço de terceiros que você visite.

Lei Aplicável

Estes Termos serão regidos e interpretados de acordo com as leis do Brasil, sem considerar suas disposições de conflito de leis.

Nossa falha em fazer valer qualquer direito ou disposição destes Termos não será considerada uma renúncia a esses direitos. Se qualquer disposição destes Termos for considerada inválida ou inexequível por um tribunal, as restantes disposições destes Termos permanecerão em vigor. Estes Termos constituem o acordo completo entre nós em relação ao nosso Serviço, e substituem e substituem quaisquer acordos anteriores que possamos ter entre nós em relação ao Serviço.

Alterações

Reservamo-nos o direito, a nosso exclusivo critério, de modificar ou substituir estes Termos a qualquer momento. Se uma revisão for material, tentaremos fornecer pelo menos 30 dias de aviso prévio antes que quaisquer novos termos entrem em vigor. O que constitui uma alteração material será determinado a nosso exclusivo critério.

Ao continuar acessando ou usando nosso Serviço após essas revisões se tornarem eficazes, você concorda em ficar vinculado pelos termos revisados. Se você não concordar com os novos termos, por favor, pare de usar o Serviço.

Contate-Nos

Se você tiver alguma dúvida sobre estes Termos, por favor, contate-nos:

Por e-mail: [Seu e-mail]
Visitando esta página no nosso website: [SeuSite.com/contato]