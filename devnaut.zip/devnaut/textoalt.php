<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

   //echo json_encode($dados);

  $nome = $dados["altNomes"];
  $idBannerAlt = $dados["tipoAlts"];


$retornoInsert = updatetexto('texto', 'nome','tipo','idtexto',"$nome","$tipo","$idtexto");
if ($retornoInsert > 0) {
   echo json_encode(['success' => true, 'message' => " Alterado com sucesso"]);

}else {
   echo json_encode(['success' => false, 'message' => "texto não Alterado ! ErroR Bd"]);

};
  
?>