

window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});

if (document.getElementById("inemail")) {
    document.getElementById("inemail").focus();
}

function fazerLogin() {

    var email = document.getElementById('inemail').value;
    var senha = document.getElementById('insenha').value;
    var errorMsg = document.getElementById('errorMsg');

    if (email === '') {
        errorMsg.style.display = 'block';
        errorMsg.innerHTML = 'O campo de email está vazio. Por favor preencha o email.';
        return;
    }
    if (senha === '') {
        errorMsg.style.display = 'block';
        errorMsg.innerHTML = 'O campo de senha está vazio. Por favor preencha o senha.';
        return;
    } else if (senha.length < 8) {
        errorMsg.style.display = 'block';
        errorMsg.innerHTML = 'A senha deve conter 8 ou mais digitos.';
        return;
    }

    mostrarProcessando()
    fetch('logar.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'email=' + encodeURIComponent(email) + '&senha=' + encodeURIComponent(senha),
    })
        .then((response) => response.json())
        .then((data) => {
            esconderProcessando();
            if (data.success) {
                setTimeout(function () {
                    esconderProcessando();
                    window.location.href = "dashboard.php"
                }, 2000);
                alert(data.message);
                errorMsg.classList.remove('alert-danger');
                errorMsg.classList.add('alert-success');
                errorMsg.innerHTML = data.message;
                errorMsg.style.display = 'block';
            } else {
                errorMsg.style.display = 'block';
                errorMsg.innerHTML = data.message;
            }
        })
        .catch(error => {
            console.error('Erro na requisição:', error);
        });

};

function mostrarProcessando() {
    var divProcessando = document.createElement('div');
    divProcessando.id = 'processandoDiv';
    divProcessando.style.position = 'fixed';
    divProcessando.style.top = '41%';
    divProcessando.style.left = '50%';
    divProcessando.style.transform = 'translate(-50%, -50%)';
    divProcessando.innerHTML = '<img src="img/processando.gif" width="300px" alt="Processando..." title="Processando..." >';
    document.body.appendChild(divProcessando);
}

// fechando loading

function esconderProcessando() {
    var divProcessando = document.getElementById("processandoDiv");
    if (divProcessando) {
        document.body.removeChild(divProcessando);
    }
}


function carregarConteudo(controle) {
    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle),
    })
        .then(response => response.text())
        .then(data => {
            document.getElementById('conteudo').innerHTML = data;
        })
        .catch(error => console.error('Erro na requisiçao'))
};








const bannerModalFechar = new bootstrap.Modal(
    document.getElementById('modalAddBanner')
);











// document.getElementById('butau').addEventListener('submit',function (event){
//     event.preventDefault();
//     alert('clicou no botão');
//     var formData = new FormData(this);
//                 formData.append('controle', 'excluirAdm');



//                 fetch('controle.php', {
//                     method: 'POST',
//                     body: formData,
//                 })
//                     .then((response) => response.json())
//                     .then(data => {
//                         console.log(data);
//                         if (data.success) {
//                             carregarConteudo('listarAdministrador')
//                      }

//                         else {

//                         }
//                     })
//                     .catch(error => {
//                         console.error('Erro na requisição:', error);
//                     });
//                 });












// const bannerModal = document.getElementById('modalAddBanner');
// const inBanner = document.getElementById('idBanner');
// const btnaddBanner = document.getElementById('btnaddBanner');

// if (bannerModal) {

//     const formCarro = document.getElementById('frmAddBanner');

//     bannerModal.addEventListener('shown.bs.modal', () => {
//         inBanner.focus();
//         const submitHandler = function (event) {
//             event.preventDefault();
//             // btnaddCarro.disabled = true;


//             var form = event.target;
//             var formData = new FormData(form);
//             formData.append('controle', 'bannerAdd');
//             var fileInput = document.getElementById('idbanner');
//             formData.append('foto', fileInput.files[0]);

//             formCarro.addEventListener('submit', submitHandler);

//             fetch('controle.php', {
//                 method: 'POST',
//                 body: formData,
//             })
//                 .then((response) => response.json())
//                 .then((data) => {
//                     console.log(data);
//                     if (data.success) {
//                         // btnaddCarro.disabled = false;
//                         bannerModalFechar.hide();
//                         setTimeout(function () {
//                             carregarConteudo('listarcarro');
//                             esconderProcessando();
//                         })
//                         form.removeEventListener('submit', submitHandler);
//                         alert('cadastrado com sucesso!');
//                     } else {
//                         alert('erro no cadastro!');
//                     }
//                 })
//                 .catch(error => {
//                     console.error('Erro na requisição:', error);
//                 });
//         };
//         formCarro.addEventListener('submit', submitHandler);
//     })
// };


// const clienteModalFechar = new bootstrap.Modal(
//     document.getElementById('modalAddcliente')
// );





function abrirModalEdicao3(carronome, carroft, det, vl, idcarro, idproprietario) {
    console.log('Nome do Carro:', carronome);
    console.log('Caminho da Foto:', carroft);
    console.log('Detalhes:', det);
    console.log('Valor:', vl);
    console.log('ID do Carro:', idcarro);
    console.log('ID do Proprietário:', idproprietario);

    var incarroeditnome = document.getElementById('idcarroedit');
    var incarrodetalheedit = document.getElementById('iddetalhesedit');
    var incarrovaloredit = document.getElementById('idvaloredit');
    var incarroeditprod = document.getElementById('idcarroeditprod');
    var sProprietario2 = document.getElementById('sProprietario2');


    if (incarroeditnome && incarrodetalheedit && incarrovaloredit && incarroeditprod && sProprietario2) {
        incarroeditnome.value = carronome;
        incarrodetalheedit.value = det;
        incarrovaloredit.value = vl;
        incarroeditprod.value = idcarro;
        sProprietario2.value = idproprietario;
    }
}





// document.getElementById('frmeditcarro').addEventListener('submit', function (event) {
//     event.preventDefault();
//     alert('clicou no botão');
//     var formData = new FormData(this);
//     formData.append('controle', 'carroAlt');
//     var fileInput = document.getElementById('fotoedit');
//     formData.append('foto', fileInput.files[0]);




//     fetch('controle.php', {
//         method: 'POST',
//         body: formData,
//     })
//         .then((response) => response.json())
//         .then(data => {
//             console.log(data);
//             if (data.success) {
//                 carregarConteudo('listarcarro')
//             }

//             else {

//             }
//         })
//         .catch(error => {
//             console.error('Erro na requisição:', error);
//         });
// });





function deletar(controle, id, listagem) {

    fetch('controle.php',
        {
            method: 'POST',
            headers: {
                'content-type': 'application/x-www-form-urlencoded',
            },
            body: 'controle=' + encodeURIComponent(controle) +
                '&id=' + encodeURIComponent(id) +
                '&listagem=' + encodeURIComponent(listagem),
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                alert('excluido com sucesso')
                carregarConteudo('listarAdministrador');
            }
            else {
                alert("Registro não deletado")
            }
        })
        .catch(error => console.error('Erro na requisiçao'))

}

function deletar2(controle, id, listagem) {

    fetch('controle.php',
        {
            method: 'POST',
            headers: {
                'content-type': 'application/x-www-form-urlencoded',
            },
            body: 'controle=' + encodeURIComponent(controle) +
                '&id=' + encodeURIComponent(id) +
                '&listagem=' + encodeURIComponent(listagem),
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                alert('excluido com sucesso')
                carregarConteudo('listarproduto');
            }
            else {
                alert("Registro não deletado")
            }
        })
        .catch(error => console.error('Erro na requisiçao'))

}

function deletarBanner(controle, id, listagem) {

    fetch('controle.php',
        {
            method: 'POST',
            headers: {
                'content-type': 'application/x-www-form-urlencoded',
            },
            body: 'controle=' + encodeURIComponent(controle) +
                '&id=' + encodeURIComponent(id) +
                '&listagem=' + encodeURIComponent(listagem),
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                alert('excluido com sucesso')
                carregarConteudo('listarbanner');
            }
            else {
                alert("Registro não deletado")
            }
        })
        .catch(error => console.error('Erro na requisiçao'))

}


// function deletarGeralProduto(controle,id){

//     fetch('controle.php',{
//         method: 'POST',
//         headers: {
//             'content-type':'application/x-www-form-urlencoded',
//         },
//         body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
//     })
//         .then(response =>response.json())
//         .then(data=> {
//            if (data.success) {
//             carregarConteudo('listarProduto')
//            }
//         })
//         .catch(error => console.error('Erro na requisiçao'))
// };       



const produtoModalFechar = new bootstrap.Modal(
    document.getElementById('modalAddProduto')
);

const produtoModal = document.getElementById('modalAddProduto');
const innome = document.getElementById('idNomeProduto');
const btnaddproduto = document.getElementById('btnAddProduto');


if (produtoModal) {

    const formProduto = document.getElementById('frmAddProduto');

    produtoModal.addEventListener('shown.bs.modal', () => {
        innome.focus();
        const submitHandler = function (event) {
            event.preventDefault();
            btnaddproduto.disabled = true;
            mostrarProcessando();

            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'produtoadd');
            var fileInput = document.getElementById('idfotoadd');
            formData.append('foto', fileInput.files[0]);
            formProduto.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        btnaddproduto.disabled = false;
                        produtoModalFechar.hide();
                        setTimeout(function () {
                            carregarConteudo('listarproduto');
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formProduto.addEventListener('submit', submitHandler);
    })
};


// cadastrar banner

const bannerModal = document.getElementById('modalAddBanner');
const innomeBanner = document.getElementById('inNomeBanner');
const btnaddbanner = document.getElementById('btnAddBanner');


if (bannerModal) {

    const formBanner = document.getElementById('frmAddBanner');

    bannerModal.addEventListener('shown.bs.modal', () => {
        innomeBanner.focus();
        const submitHandler = function (event) {
            event.preventDefault();
            btnaddbanner.disabled = true;
            mostrarProcessando();

            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'bannerAdd');
            var fileInput = document.getElementById('inFotoBanner');
            formData.append('foto', fileInput.files[0]);
            formBanner.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        btnaddbanner.disabled = false;
                        bannerModalFechar.hide();
                        setTimeout(function () {
                            carregarConteudo('listarbanner');
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formBanner.addEventListener('submit', submitHandler);
    })
};






function abrirModalEdicao2(NomeAlt, DetalhesAlt, LancamentoAlts, tipoAlts, idproduto) {
    var idNomeProduto = document.getElementById('NomeProdutoAlt');
    var idDetalhesAlt = document.getElementById('DetalhesAlt');
    var LancamentoAlt = document.getElementById('LancamentoAlt');
    var tipoAlt = document.getElementById('tipoAlt');


    if (idNomeProduto && idDetalhesAlt && LancamentoAlt && tipoAlt) {
        idNomeProduto.focus();
    }


    idNomeProduto.value = NomeAlt
    idDetalhesAlt.value = DetalhesAlt
    LancamentoAlt.value = LancamentoAlts
    tipoAlt.value = tipoAlts

    document.getElementById('produtoalt').value = idproduto

};


const produtosModalFechar = new bootstrap.Modal(
    document.getElementById('modalAltProduto')
);

document.getElementById('frmAltProduto').addEventListener('submit', function (event) {
    event.preventDefault();
    var formData = new FormData(this);
    formData.append('controle', 'produtoalt');
    var fileInput = document.getElementById('fotoAlt');
    formData.append('foto', fileInput.files[0]);


    fetch('controle.php', {
        method: 'POST',
        body: formData,
    })
        .then((response) => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {


                carregarConteudo('listarproduto')

                form.removeEventListener('submit',submitHandler);
                alert('Alterado com sucesso!')

            }

            else {
                alert('erro no Alterar!');
            }
        })
        .catch(error => {
            console.error('Erro na requisição:',error);
        });
});


const cadastrarModalFechar = new bootstrap.Modal(
    document.getElementById('cadastrar')
);

const cadastrarModal = document.getElementById('cadastrar');
const idnomeContato = document.getElementById('nomeContato');
const btncadastrar = document.getElementById('btncadastrar');


if (cadastrarModal) {

    const formcadastrar = document.getElementById('frmcadastrar');

    cadastrarModal.addEventListener('shown.bs.modal', () => {
        idnomeContato.focus();
        const submitHandler = function (event) {
            event.preventDefault();
            btncadastrar.disabled = true;
            mostrarProcessando();

            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'listarprincipal');

            formcadastrar.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        btncadastrar.disabled = false;
                        cadastrarModalFechar.hide();
                        setTimeout(function () {
                            header("Location: index.php")
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formcadastrar.addEventListener('submit', submitHandler);
    })
};

// alterar banner

function abrirModalEdicao3(idNomeBanner, idBannerAlt) {

    var idBannerNome = document.getElementById('idNomeBanner');
    if (idBannerNome) {
        idBannerNome.focus();
       
    }
    idBannerNome.value = idNomeBanner

    document.getElementById('idBannerAlt').value = idBannerAlt

};

const bannerAltModalFechar = new bootstrap.Modal(
    document.getElementById('modalAltBanner')
);

document.getElementById('frmAltBanner').addEventListener('submit', function (event) {
    event.preventDefault();
    var formData = new FormData(this);
    formData.append('controle', 'alterarBanner');
    var fileInput = document.getElementById('fotoBannerAlt');
    formData.append('foto', fileInput.files[0]);


    fetch('controle.php', {
        method: 'POST',
        body: formData,
    })
        .then((response) => response.json())
        .then(data => {
            console.log(data);
            alert('marcao')
            if (data.success) {
                
                carregarConteudo('listarbanner')
                form.removeEventListener('submit', submitHandler);
                alert('Alterado com sucesso!')

            }

            else {
                alert('erro no Alterar!');
            }
        })
        .catch(error => {
            console.error('Erro na requisição:', error);
        });
});



function abrirModalEdicaotexto(NomeAlt, tipotextAlt,idtextoAlt) {

    var idTextoNome = document.getElementById('NomeAlt');
    if (idTextoNome) {
        idTextoNome.focus();
       
    }
    idTextoNome.value = NomeAlt

    document.getElementById('tipotextAlt').value = tipotextAlt

};

const textoAltModalFechar = new bootstrap.Modal(
    document.getElementById('modalAltTexto')
);

document.getElementById('frmAltTexto').addEventListener('submit', function (event) {
    event.preventDefault();
    var formData = new FormData(this);
    formData.append('controle', 'textoalt');

    fetch('controle.php', {
        method: 'POST',
        body: formData,
    })
        .then((response) => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                alert('marcao')
                carregarConteudo('listartexto')
                form.removeEventListener('submit', submitHandler);
                alert('Alterado com sucesso!')

            }

            else {
                alert('erro no Alterar!');
            }
        })
        .catch(error => {
            console.error('Erro na requisição:', error);
        });
});