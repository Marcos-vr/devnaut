

window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});

if (document.getElementById("inemail")) {
    document.getElementById("inemail").focus();
}

function fazerLogin() {

    var email = document.getElementById('inemail').value;
    var senha = document.getElementById('insenha').value;
    var errorMsg = document.getElementById('errorMsg');

    if (email === '') {
        errorMsg.style.display = 'block';
        errorMsg.innerHTML = 'O campo de email está vazio. Por favor preencha o email.';
        return;
    }
    if (senha === '') {
        errorMsg.style.display = 'block';
        errorMsg.innerHTML = 'O campo de senha está vazio. Por favor preencha o senha.';
        return;
    } else if (senha.length < 8) {
        errorMsg.style.display = 'block';
        errorMsg.innerHTML = 'A senha deve conter 8 ou mais digitos.';
        return;
    }

    mostrarProcessando()
    fetch('logar.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'email=' + encodeURIComponent(email) + '&senha=' + encodeURIComponent(senha),
    })
        .then((response) => response.json())
        .then((data) => {
            esconderProcessando();
            if (data.success) {
                setTimeout(function () {
                    esconderProcessando();
                    window.location.href = "dashboard.php"
                }, 2000);
                alert(data.message);
                errorMsg.classList.remove('alert-danger');
                errorMsg.classList.add('alert-success');
                errorMsg.innerHTML = data.message;
                errorMsg.style.display = 'block';
            } else {
                errorMsg.style.display = 'block';
                errorMsg.innerHTML = data.message;
            }
        })
        .catch(error => {
            console.error('Erro na requisição:', error);
        });

};

function mostrarProcessando() {
    var divProcessando = document.createElement('div');
    divProcessando.id = 'processandoDiv';
    divProcessando.style.position = 'fixed';
    divProcessando.style.top = '41%';
    divProcessando.style.left = '50%';
    divProcessando.style.transform = 'translate(-50%, -50%)';
    divProcessando.innerHTML = '<img src="img/processando.gif" width="200px" alt="Processando..." title="Processando..." >';
    document.body.appendChild(divProcessando);
}

// fechando loading

function esconderProcessando() {
    var divProcessando = document.getElementById("processandoDiv");
    if (divProcessando) {
        document.body.removeChild(divProcessando);
    }
}


function carregarConteudo(controle){
    fetch('controle.php',{
        method: 'POST',
        headers: {
            'content-type':'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle),
    })
        .then(response =>response.text())
        .then(data=> {
            document.getElementById('conteudo').innerHTML = data;
        })
        .catch(error => console.error('Erro na requisiçao'))
};








// const carroModalFechar = new bootstrap.Modal(
//     document.getElementById('modalAddCarro')
// );








            
 

            document.getElementById('frmeditcliente').addEventListener('submit',function (event){
                event.preventDefault();
                alert('clicou no botão');
                var formData = new FormData(this);
                            formData.append('controle', 'clienteAlt');
                
                        
                
                            fetch('controle.php', {
                                method: 'POST',
                                body: formData,
                            })
                                .then((response) => response.json())
                                .then(data => {
                                    console.log(data);
                                    if (data.success) {
                                        carregarConteudo('listarcliente')
                                 }
                                    
                                    else {
                                      
                                    }
                                })
                                .catch(error => {
                                    console.error('Erro na requisição:', error);
                                });
                            });
                
        

function abrirModalEdicao2(cliente,cliente2,cliente3,idcliente){
    var inclienteedit = document.getElementById('clienteedit');
    var inclienteedit2 = document.getElementById('clienteedit2');
    var inclienteedit3 = document.getElementById('clienteedit3');
    if (inclienteedit && inclienteedit2 && inclienteedit3 ) {
        inclienteedit.focus();
    }
    inclienteedit.value = cliente
    inclienteedit2.value = cliente2
    inclienteedit3.value = cliente3
    document.getElementById('idclienteedit').value = idcliente

};




      
        

            


                
                
                const carroModal = document.getElementById('modalAddCarro');
                const inCarro = document.getElementById('idCarro');
                const btnaddCarro = document.getElementById('btnaddCarro');

                if (carroModal) {

                    const formCarro = document.getElementById('frmAddCarro');
                
                    carroModal.addEventListener('shown.bs.modal', () => {
                        inCarro.focus();
                        const submitHandler = function (event) {
                            event.preventDefault();
                            // btnaddCarro.disabled = true;
                      
                
                            var form = event.target;
                            var formData = new FormData(form);
                            formData.append('controle', 'carroAdd');
                             var fileInput = document.getElementById('idCarro2');
                             formData.append('foto', fileInput.files[0]);
                
                            formCarro.addEventListener('submit', submitHandler);
                
                            fetch('controle.php', {
                                method: 'POST',
                                body: formData,
                            })
                                .then((response) => response.json())
                                .then((data) => {
                                    console.log(data);
                                    if (data.success) {
                                        // btnaddCarro.disabled = false;
                                        carroModalFechar.hide();
                                        setTimeout(function () {
                                            carregarConteudo('listarcarro');
                                            esconderProcessando();
                                        })
                                        form.removeEventListener('submit', submitHandler);
                                        alert('cadastrado com sucesso!');
                                    } else {
                                        alert('erro no cadastro!');
                                    }
                                })
                                .catch(error => {
                                    console.error('Erro na requisição:', error);
                                });
                        };
                        formCarro.addEventListener('submit', submitHandler);
                    })
                };


                const clienteModalFechar = new bootstrap.Modal(
                    document.getElementById('modalAddcliente')
                );
                     
               
const clienteModal = document.getElementById('modalAddcliente');
const incliente = document.getElementById('idcliente1');
const incliente2 = document.getElementById('idcliente2');
const btnaddcliente = document.getElementById('btnAddcliente');


            
            
if (clienteModal) {

    const formCliente = document.getElementById('frmAddcliente');

    clienteModal.addEventListener('shown.bs.modal', () => {
        incliente.focus();
        const submitHandler = function (event) {
            event.preventDefault();
            btnaddcliente.disabled = true;
            mostrarProcessando();

            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'clienteAdd');

            formCliente.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        btnaddcliente.disabled = false;
                        clienteModalFechar.hide();
                        setTimeout(function () {
                            carregarConteudo('listarcliente');
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formCliente.addEventListener('submit', submitHandler);
    })
}; 



function abrirModalEdicao3(carronome, carroft, det, vl, idcarro, idproprietario) {
    console.log('Nome do Carro:', carronome);
    console.log('Caminho da Foto:', carroft);
    console.log('Detalhes:', det);
    console.log('Valor:', vl);
    console.log('ID do Carro:', idcarro);
    console.log('ID do Proprietário:', idproprietario);

    var incarroeditnome = document.getElementById('idcarroedit');
    var incarrodetalheedit = document.getElementById('iddetalhesedit');
    var incarrovaloredit = document.getElementById('idvaloredit');
    var incarroeditprod = document.getElementById('idcarroeditprod');
    var sProprietario2 = document.getElementById('sProprietario2');


    if (incarroeditnome && incarrodetalheedit && incarrovaloredit && incarroeditprod && sProprietario2) {
        incarroeditnome.value = carronome;
        incarrodetalheedit.value = det;
        incarrovaloredit.value = vl;
        incarroeditprod.value = idcarro;
        sProprietario2.value = idproprietario;
    }
}





document.getElementById('frmeditcarro').addEventListener('submit',function (event){
    event.preventDefault();
    alert('clicou no botão');
    var formData = new FormData(this);
                formData.append('controle', 'carroAlt');
                var fileInput = document.getElementById('fotoedit');
                formData.append('foto', fileInput.files[0]);
   
    
            
    
                fetch('controle.php', {
                    method: 'POST',
                    body: formData,
                })
                    .then((response) => response.json())
                    .then(data => {
                        console.log(data);
                        if (data.success) {
                            carregarConteudo('listarcarro')
                     }
                        
                        else {
                          
                        }
                    })
                    .catch(error => {
                        console.error('Erro na requisição:', error);
                    });
                });
    


            

function deletar(controle,id) {

    fetch('controle.php',{
        method: 'POST',
        headers: {
            'content-type':'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' +  encodeURIComponent(id)
    })
        .then(response =>response.json())
        .then(data=> {
            if (data.success) {
                carregarConteudo('listarAdministrador');

                alert('excluido com sucesso')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))

}

                
                