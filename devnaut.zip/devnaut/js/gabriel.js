

const TextoModal = document.getElementById('modalAddTexto');
const inTexto = document.getElementById('textoNome');
const btnaddTexto = document.getElementById('btnAddTexto');


if (TextoModal) {



    const formTexto = document.getElementById('frmAddTexto');

    TextoModal.addEventListener('shown.bs.modal', () => {
        inTexto.focus();
        const submitHandler = function (event) {
            event.preventDefault();
            btnaddTexto.disabled = true;
            mostrarProcessando();

            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'textoAdd');

            formTexto.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        btnaddTexto.disabled = false;
                        TextoModalFechar.hide();
                        setTimeout(function () {
                            carregarConteudo('listarTexto');
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formTexto.addEventListener('submit', submitHandler);
    })
};
