<?php

include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//echo json_encode($dados)


$nome = $dados["nomeadd"];
$detalhes = $dados["Detalhesadd"];
$lancamento = $dados["Lancamentoaddp"] ;
$tipo = $dados["tipoadd"] ;


if (isset($_FILES['foto'])&& $_FILES['foto']['error']==UPLOAD_ERR_OK ){
    $fotoTmpNome = $_FILES['foto']['tmp_name'];
    $fotoName = $_FILES['foto']['name'];
    $uploadDir = 'img';
    $fotoPath = uniqid().'_'.$fotoName;
    if (move_uploaded_file($fotoTmpNome,$uploadDir.'/'.$fotoPath)){


    $retornoInsert = insertCincoId('jogos', 'nome, detalhes, lancamento, foto, tipo',"$nome","$detalhes","$lancamento","$fotoPath","$tipo");

   //echo json_encode($retornoInsert);
    if ($retornoInsert > 0) {
        echo json_encode(['success' => true, 'message' => "Jogo cadastro com sucesso"]);

    }else {
        echo json_encode(['success' => false, 'message' => "Genero nao cadastrado! Error Bd"]);
    }
}else {
    echo json_encode(['success' => false, 'message' => "Genero nao cadastrado! Error variavel"]);
 }
 };

?>
