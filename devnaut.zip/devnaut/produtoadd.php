<?php

include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

echo json_encode($dados)

// if (!empty($dados) && isset($dados)) {


//     $cliente = isset($dados["nomeadd"])? addslashes(mb_strtoupper($dados["nomeadd"], 'UTF-8')): '';
//     $cpf = isset($dados["Detalhesadd"])? addslashes(mb_strtoupper($dados["Detalhesadd"], 'UTF-8')): '';
//     $nascimento = isset($dados["Lancamentoaddp"])? addslashes(mb_strtoupper($dados["Lancamentoaddp"], 'UTF-8')): '';
//     $foto = isset($dados["fotoadd"])? addslashes(mb_strtoupper($dados["fotoadd"], 'UTF-8')): '';

//     $retornoInsert = insertTresId('jogos','nome, detalhes,lancamento , foto',"$jogos","$detalhes","$lancamento","$foto");

// //    echo json_encode($retornoInsert);
//     if ($retornoInsert > 0) {
//         echo json_encode(['success' => true, 'message' => "Jogo cadastro com sucesso"]);

//     }else {
//         echo json_encode(['success' => false, 'message' => "Genero nao cadastrado! Error Bd"]);
//     }
// }else {
//     echo json_encode(['success' => false, 'message' => "Genero nao cadastrado! Error variavel"]);

// };

?>
