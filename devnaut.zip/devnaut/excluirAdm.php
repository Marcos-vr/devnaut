<?php
include_once './config/conexao.php';
include_once './config/constantes.php';
include_once './func/funcoes.php';


$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

// echo json_encode($dados);


if (!empty($dados) && isset($dados)) {
    $idadm = isset($dados["id"]) ? addslashes(mb_strtoupper($dados["id"], 'UTF-8')) : '';
    $retornoDelete = deletar('adm', 'idadm', $idadm);


    if ($retornoDelete > 0) {
        echo json_encode(['success' => true, 'message' => "ADM Excluido com sucesso" ]);

    } else {
        echo json_encode(['success' => false, 'message' => "ADM não Excluido! ErroR Bd"]);

    }
} else {
    echo json_encode(['success' => false, 'message' => "ADM não Excluido! Error Variável"]);
};





