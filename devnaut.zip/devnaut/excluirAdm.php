<?php

include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
$conn = conectar();


    $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
    echo json_encode($dados)


    // if (!empty($dados) && isset($dados)) {

    //     $idgenero = isset($dados["id"])? intval($dados["id"]) : 0;


    //     $retornoDelete = deletar('adm', 'idadm' , $idadm);

    //     if ($retornoDelete > 0) {
    //         echo json_encode(['success' => true, 'message' => "Genero  Excluido com sucesso"]);

    //     }else {
    //         echo json_encode(['success' => false, 'message' => "Genero nao Excluido! Error Bd"]);
    //     }
    // }else {
    //     echo json_encode(['success' => false, 'message' => "Genero nao Excluido! Error variavel"]);

    // };




?>
