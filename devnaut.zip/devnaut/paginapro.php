<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';


if (isset($_GET["id"]) & !empty($_GET["id"])) {
    $id = $_GET["id"];
};

?>


<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Principal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>

<body class="fundo kanit-regular">
    <nav class="  navbar navbar-expand-lg navbg shadow textos sticky-top navstyle ">
        <a href="index.php">
            <img width="110px" src="img./dev2.png" alt="">
        </a>
        <button class="navbar-toggler fundoicon" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active text-white " aria-current="page" href="#">
                        <span class="texto">Home</span>
                    </a>
                </li>
                <li class="nav-item dropdown text-white drop">

                    <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="texto">
                            Jogos
                        </span>
                    </a>
                    </span>
                    <ul class="dropdown-menu text-white texto">
                        <li><a class="dropdown-item drop" href="#">Console</a></li>
                        <li><a class="dropdown-item drop" href="#">Pc</a></li>

                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" aria-disabled="true" href="login.php">
                        <span class="texto">Login</span>
                    </a>
                </li>
            </ul>
            <form class="d-flex" role="search">

                <button class="btn  text-white" type="submit"></button>

            </form>
            <button class="btn text-white " aria-disabled="true" data-bs-toggle="modal" data-bs-target="#contato">
                <span class="texto"><i class=" fa-solid fa-address-book me-1"></i> Contato</span>
            </button>
        </div>
        </div>
    </nav>


    <div class="container-fluid ">
        <div class="row">
            <?php
            $retornojogos = listarTabela('idjogos, nome, detalhes, Lancamento, foto, tipo', 'jogos', 'idjogos');
            if ($retornojogos != 'Vazio') {
                foreach ($retornojogos as $jogo) {
                    $idjogos = $jogo->idjogos;
                    $nome = $jogo->nome;
                    $detalhes = $jogo->detalhes;
                    $Lancamento = $jogo->Lancamento;
                    $foto = $jogo->foto;
                    $tipo = $jogo->tipo;

                    if ($id == $idjogos) {



            ?>

                        <div class="card rounded-5 mb-3 navbg position-absolute top-50 start-50 translate-middle mt-5 col-12" style="width: 80%;">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img class="" style="width: 100%;" src="img/<?php echo $foto ?>" alt="">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title text-center text-white"><?php echo $nome ?></h5>
                                        <p class="card-text mt-5 text-white"><?php echo $detalhes ?></p>

                                        <h5 class="card-text"><small class=" mt-5 text-white ">Lançamento</small></h5>
                                        <p class="card-text text-white"><small class="text-white"><?php echo $Lancamento ?></small></p>
                                    </div>
                                </div>
                            </div>
                        </div>



            <?php
                    }
                }
            };
            ?>


        </div>
    </div>
    <div>
  
    </div>
</body>

</html>