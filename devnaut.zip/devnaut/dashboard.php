<?php

include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

if ($_SESSION['idadm']) {
    $idusuarioSession = $_SESSION['idadm'];
} else {
    session_destroy();
    header('location: ./index.php=404');
    die();
};

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>

<body>
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="#"><img width="150px" src="img/Dev2.png" alt=""></a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">

            </div>
        </form>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4 ">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="index.php">Principal</a></li>
                    <li><a class="dropdown-item" href="login.php">Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Dashboard</div>
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Menu
                        </a>
                        <div class="sb-sidenav-menu-heading">Interface</div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Layouts
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" onclick="carregarConteudo('listarbanner')" href="#">Banner</a>
                                <a class="nav-link" onclick="carregarConteudo('listarproduto')" href="#">Produto</a>
                                <a class="nav-link" onclick="carregarConteudo('listartexto')" href="#">Texto</a>
                            </nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                            Area Retrita Dados
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">
                                    Cliente
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                </a>
                                <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                                    <nav class="sb-sidenav-menu-nested nav">
                                        <a class="nav-link" onclick="carregarConteudo('listarcontato')" href="#">Contato</a>
                                    </nav>
                                </div>
                                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">
                                    ADM
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                </a>
                                <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                                    <nav class="sb-sidenav-menu-nested nav">
                                        <a class="nav-link" onclick="carregarConteudo('listarAdministrador')" href="#">Adm</a>

                                    </nav>
                                </div>
                            </nav>
                        </div>

                    </div>
                </div>
            </nav>
        </div>

        <div class="container-fluid px-4">
            <div id="layoutSidenav_content">
                <main>
                </main>


                <div class=" px-4" id="conteudo">
                    <div class="col-md-12 text-dark position-absolute top-50 start-50 translate-middle">
                        <h1 class="text-center">Bem vindo!!</h1>
                        <div class="text-center">
                            <?php
                            $hoje = date('d/m/Y');
                            echo $hoje;
                            ?>
                        </div>
                    </div>



                </div>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; 2024 Master Games. Todos os direitos reservados. Transformando ideias em realidade, um clique de cada vez.</div>
                            <div>
                                <a href="politica.php" target="blank">Privacy Policy</a>
                                &middot;
                                <a href="termos.php" target="blank">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>


        <!-- modal cadastrar banner -->


        <div class="modal fade" id="modalAddBanner" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">CADASTRO</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">
                            <div class="card-header">
                                Cadastrar Banner
                            </div>
                            <div class="card-body">
                                <form name="frmAddBanner" id="frmAddBanner" method="post" action="#">
                                    <div class="mb-3">
                                        <label for="inFotoBanner" class="form-label">Foto</label>
                                        <input type="file" class="form-control" name="fotoadd" id="inFotoBanner">
                                    </div>
                                    <div class="mb-3">
                                        <label for="inNomeBanner" class="form-label">NOME</label>
                                        <input type="text" class="form-control" name="nomeadd" id="inNomeBanner" aria-describedby="emailHelp">
                                    </div>

                                    <button type="submit" class="btn btn-primary" id="btnAddBanner">CADASTRAR</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">FECHAR</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal de cadastrar jogos -->

        <div class="modal fade" id="modalAddProduto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">CADASTRO</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">
                            <div class="card-header">
                                Cadastro
                            </div>
                            <div class="card-body">
                                <form name="frmAddProduto" id="frmAddProduto" method="post" action="#">
                                    <div class="mb-3">
                                        <label for="idNomeProduto" class="form-label">Nome</label>
                                        <input type="text" class="form-control" name="nomeadd" id="idNomeProduto" aria-describedby="emailHelp">
                                    </div>
                                    <div class="mb-3">
                                        <label for="idDetalhesadd" class="form-label">Detalhes</label>
                                        <input type="text" class="form-control" name="Detalhesadd" id="idDetalhesadd">
                                    </div>
                                    <div class="mb-3">
                                        <label for="idLancamentoaddp" class="form-label">Lançamento</label>
                                        <input type="date" class="form-control" name="Lancamentoaddp" id="idLancamentoaddp">

                                    </div>
                                    <div class="mb-3">
                                        <label for="idtipoadd" class="form-label">Tipo</label>
                                        <input type="texto" class="form-control" name="tipoadd" id="idtipoadd">

                                    </div>

                                    <div class="mb-3">
                                        <label for="idfotoadd" class="form-label">Foto</label>
                                        <input type="file" class="form-control" name="fotoadd" id="idfotoadd">

                                    </div>

                                    <button type="submit" class="btn btn-primary" id="btnAddProduto">CADASTRAR</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal de alterar jogos -->

        <div class="modal fade" id="modalAltProduto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Alteração</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">
                            <div class="card-header">
                                Alteração
                            </div>
                            <div class="card-body">
                                <form name="frmAltProduto" id="frmAltProduto" method="post" action="#">
                                    <div class="mb-3">

                                        <label for="NomeProduto" class="form-label">Nome</label>
                                        <input type="text" class="form-control" name="NomeAlt" id="NomeProdutoAlt">
                                    </div>
                                    <div class="mb-3">
                                        <label for="DetalhesAlt" class="form-label">Detalhes</label>
                                        <input type="text" class="form-control" name="DetalhesAlts" id="DetalhesAlt">
                                    </div>
                                    <div class="mb-3">
                                        <label for="LancamentoAlt" class="form-label">Lançamento</label>
                                        <input type="date" class="form-control" name="LancamentoAlts" id="LancamentoAlt">

                                    </div>
                                    <div class="mb-3">
                                        <label for="tipoAlt" class="form-label">Tipo</label>
                                        <input type="texto" class="form-control" name="tipoAlts" id="tipoAlt">

                                    </div>

                                    <div class="mb-3">
                                        <label for="fotoAlt" class="form-label">Foto</label>
                                        <input type="file" class="form-control" name="fotoAlts" id="fotoAlt">
                                        <input type="hidden" class="form-control mt-3" name="produtoalts" id="produtoalt" aria-describedby="emailHelp">
                                    </div>

                                    <button type="submit" class="btn btn-primary" id="btnAltProduto">Alterar</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal add Adm-->

        <div class="modal fade" id="admcadastrar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">CADASTRO</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">
                            <div class="card-header">
                                Cadastrar Adm
                            </div>
                            <div class="card-body">
                                <form action="redirect.php" method="POST" name="cadastroUsuario">
                                    <div class="mb-3">
                                        <label for="impnomecad" class="form-label">Nome</label>
                                        <input type="text" class="form-control" id="impnomecad" name="impnomecad">
                                    </div>
                                    <div class="mb-3">
                                        <label for="impemailcad" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="impemailcad" name="impemailcad" aria-describedby="emailHelp">
                                    </div>
                                    <div class="mb-3">
                                        <label for="impsenhacad" class="form-label">Senha</label>
                                        <input type="password" class="form-control" id="impsenhacad" name="impsenhacad" aria-describedby="emailHelp">
                                    </div>

                                    <button type="submit" class="btn btn-primary custom-button imgf btns-login">CADASTRAR</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">FECHAR</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cadastrar texto modal -->

        <div class="modal fade" id="modalAddTexto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">CADASTRO</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">

                            <div class="card-body">
                                <form method="post" name="frmAddTexto" action="#">
                                    <div class="mb-3">
                                        <label for="textoNome" class="form-label">Nome</label>
                                        <input type="text" class="form-control" id="textoNome" name="textoNomes">
                                    </div>
                                    <div class="mb-3">
                                        <label for="tipoAdd" class="form-label">Tipo</label>
                                        <input type="text" class="form-control" id="tipoAdd" name="tipoAdds" aria-describedby="textoHelp">
                                    </div>

                                    <button type="submit" class="btn btn-primary" id="btnAddTexto">CADASTRAR</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">FECHAR</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



<!-- Alterar texto -->

        <div class="modal fade" id="modalAltTexto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">CADASTRO</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">

                            <div class="card-body">
                                <form method="post" name="frmAltTexto" action="#">
                                    <div class="mb-3">
                                        <label for="NomeAlt" class="form-label">Nome</label>
                                        <input type="text" class="form-control" id="NomeAlt" name="altNomes">
                                    </div>
                                    <div class="mb-3">
                                        <label for="tipotextAlt" class="form-label">Tipo</label>
                                        <input type="text" class="form-control" id="tipotextAlt" name="tipoAlts" aria-describedby="textoHelp">
                                        <input type="text" class="form-control mt-3" name="idtextoAlter" id="idtextoAlt" aria-describedby="emailHelp">
                                    </div>

                                    <button type="submit" class="btn btn-primary" id="btnAltTexto">Alterar</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">FECHAR</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <!-- Modal alterar banner -->

        
        <div class="modal fade" id="modalAltBanner" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Alterar Banner</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">
                            <div class="card-header">
                                Alteração
                            </div>
                            <div class="card-body">
                                <form name="frmAltBanner" id="frmAltBanner" method="POST" action="#">
                                    <div class="mb-3">
                                        <label for="idNomeBanner" class="form-label">Nome</label>
                                        <input type="text" class="form-control" name="nomeBannerAlt" id="idNomeBanner">
                                    </div>
                                    <div class="mb-3">
                                        <label for="fotoBannerAlt" class="form-label">Foto</label>
                                        <input type="file" class="form-control" name="bannerAlter" id="fotoBannerAlt">
                                        <input type="hidden" class="form-control mt-3" name="idBannerAlter" id="idBannerAlt" aria-describedby="emailHelp">
                                    </div>
                                    <button type="submit" class="btn btn-primary" id="btnAltBanner">Alterar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="js/gabriel.js"></script>

</body>

</html>