<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<title>Login ADM</title>

</head>

<body>
    


        <div class="main-login">
            <div class="left-login">
                <h1>Seja Bem-Vindo ADM<br> Esse e Nosso segredo Não Diga a Ninguem </h1>
                <img src="gamer.svg" class="left-login-image" alt="Hacker">
            </div>
            <form action="#" name='jogos' method="post" id="loginform">
                <div class="right-login">
                    <div class="card-login">
                        <h1> LOGIN ADM</h1>
                        <div class="textfield">
                            <label for="impemail">Email:</label>
                            <input type="email" placeholder="Email" id="inemail" name="inemail">
                        </div>
                        <div class="textfield">
                            <label for="senha">Senha:</label>
                            <input type="password" id="insenha" name="insenha" placeholder="Senha">
                            
                        </div>
                        <button type="button" class="btns-login" onclick="fazerLogin()" name="btn-login">Login</button>
                    </div>
                </div>
            </form>
        </div>
    

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="./js/login.js"></script>
    <script src="./js/teste.js"></script>
    <script src="./js/scripts.js"></script>
    
</body>

</html>