<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

    <div class="container position-absolute top-50 start-50 translate-middle" style=width:480px>

        <div class="card row p-3 mb-5 bg-white rounded">
            <h2 class="text-center mt-2">Login</h2>
            <form class="mt-4" name='cinema' action="#" method="post" id="loginform">
                <div class="mb-4 ">
                    <label for="impemail" class="form-label text-white">
                        <h5>Email</h5>
                    </label>
                    <input type="email"  class="form-control inputLogin " id="impemail" aria-describedby="emailHelp" placeholder="Digite o email:" required=required>
                </div>
                <div class="mb-3 ">
                    <label for="impsenha" class="form-label text-white">
                        <h5>Senha</h5>
                    </label>
                    <input type="password"  class="form-control inputLogin shadow" id="impsenha" placeholder="Digite a senha:" required=required>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button class="btn btn-lg btn-outline-dark me-md-2 btnlogin" type="button" onclick="fazerLogin()" name="btn-login">Entrar</button>
                </div>
            </form>
            <div class="alert alert-danger" role="alert" style="margin-top: 15px; display: none;" id="errorMsg">
                Senha menor que 8 digitos.
            </div>
        </div>
    </div>


    

    <script src="./js/teste.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>