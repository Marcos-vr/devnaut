<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
if (!empty($_POST['email'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];
};

$retornoValidar = validarSenhaCriptografia('idadm, nome, email, senha', 'adm', 'email', 'senha', "$email", "$senha");
if ($retornoValidar) {
    if ($retornoValidar == 'usuario') {
        echo json_encode(['success' => false, 'message' => 'Email inválido']);
    } else if ($retornoValidar == 'senha') {
        echo json_encode(['success' => false, 'message' => 'Senha inválida']);
    } else {
        echo json_encode(['success' => true, 'message' => "Logado com sucesso! Redirecionando... $email"]);
        $_SESSION['idadm'] = $retornoValidar->idadm;
        $_SESSION['nome'] = $retornoValidar->nome;
        $_SESSION['email'] = $retornoValidar->email;
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Usuário e Senha inválidos']);
}



?>