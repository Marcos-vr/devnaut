<?php
include('bd.php');

if (isset($_GET['id'])) {
    $idi = $_GET['id'];
    $indice = ($idi - 1);
    unset($produtos[$indice]);
}else{
    $idi = 0;
}


?>
<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos</title>
</head>

<body>
    <div>
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="adm.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Produtos</li>
            </ol>
        </nav>
    </div>
    <div class="container">
        <div class="card" style="width: 80%; ">
            <div class="card-header col-md-12">
                #produtos
                <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal" style="float: right;">
                    Cadastrar
                </button>
            </div>
            <div class="container">
                <tbody class="table text-center" style="width: 80%;">
                    <tr class="text-center">
                        <th>Produtos</th>
                        <th>Ação</th>
                    </tr>
                    <tr>
                        <div class="row">
                            <?php
                            foreach ($produtos as $produtositem) {
                                $id = $produtositem['id'];
                                $nome = $produtositem['nome'];
                                $foto = $produtositem['foto'];
                                $tipo = $produtositem['tipo'];
                                $ativo = $produtositem['ativo'];
                                if ($tipo == 'p') { 
                            ?>
                                    <div class="col-md-6">
                                        <td>
                                            <img src="<?php echo $foto ?>" alt="" srcset="" class="card img-fluid rounded start">
                                        </td>
                                    </div>
                                    <div class="col-md-6">
                                        <td>
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <button type="button" class="btn btn-success">Ver +</button>
                                                <a href="adm.php?page=produtos&id=<?php echo $id; ?>" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal">Editar</a>
                                                <a href="adm.php?page=produtos&id=<?php echo $id; ?>" class="btn btn-danger">Excluir</a>
                                            </div>
                                        </td>
                                        <hr>
                                    </div>
                            <?php
                                }
                            };
                            ?>
                            <!-- Button trigger modal -->


                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body bg-secondary">
                                            <?php
 
                                                foreach ($produtos as $produtositem) {
                                                    $id = $produtositem['id'];
                                                    $nome = $produtositem['nome'];
                                                    $foto = $produtositem['foto'];
                                                    $tipo = $produtositem['tipo'];
                                                    $ativo = $produtositem['ativo'];

                                                    if($id==$idi){
                                                        ?>

                                                        <form>
                                                            
                                                        </form>
                                                        <?php
                                                    }
                                                }
                                            ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </tbody>
            </div>
        </div>
    </div>
    </div>
    </div>
</body>

</html>