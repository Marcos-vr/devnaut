<?php
session_start();
if (isset($_SESSION['index'])) {
    $adm = $_SESSION['index'];
} else {
    $adm = 0;
}

if (isset($adm) && !empty($adm)) {
    if ($adm == 1) {
        $operador = 'ADM';
    } elseif ($adm == 2) {
        $operador = $_SESSION['nomeusuario'];
    } elseif ($adm == 3) {
        $operador = 'Cliente';
    } else {
        $operador = '';
        session_destroy();
    }
} else {
    $operador = '';
}
;
include('bd.php');

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <br>
    <title>Books on the <tb>
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300&family=Josefin+Sans:wght@600&display=swap"
        rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body class="bgcards logo">
    <nav class="navbar fixed-top navbar-expand-lg bg-secondary shadow" style="opacity: 0.95; height: 90px;">
        <div class="container-fluid bg-tertiary">
            <ul class="navbar-nav me-auto mb-1 mb-lg-0">
                <li class="nav-item logo text-white">
                    <a class="navbar-brand text-white shadow" href="#">
                        <img src="img/icone.png" alt="">
                        <h5>Books on the ‹tb›</h5>
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <center>
                    <li class="nav-item">

                        <?php
                        if (!isset($_SESSION['index'])) {
                            ?>

                            <a class="nav-link  text-light" aria-current="page" href="./cadastro.php">
                                <h5 class="mouse">Iniciar Sessão </h5>
                            </a>

                            <?php echo ' ' . $operador; ?>
                        </li>
                    </center>
                    <?php
                        } else {
                            ?>
                    <a class="nav-link  text-light fixed-top text-center" aria-current="page" href="./cadastro.php"> </a>
                    <?php echo ' ' . $operador; ?>
                    </li>
                    <?php
                        }
                        ?>

                </a>
                </li>
                <li class="nav-item">
                    <a class="navbar-brand text-white">

                    </a>
                </li>
            </ul>
            <a class="btn btn-danger" aria-current="page" href="./sair.php">Sair</a>
        </div>
    </nav>


    <div id="carouselExampleCaptions" class="carousel slide container mt-1">

        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
        </div>
        <br>

        <div class="carousel-inner container mt-5">
            <?php
            foreach ($banner as $banneritem) {
                $nome = $banneritem['nome'];
                $foto = $banneritem['foto'];
                $tipo = $banneritem['tipo'];
                $ativo = $banneritem['ativo'];
                if ($ativo == 'a') {
                    ?>
                    <div class="carousel-item active">

                        <img src="<?php echo $foto ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>First slide label</h5>
                            <p>Some representative placeholder content for the first slide.</p>
                        </div>
                    </div>
                    <?php
                }
                ;
            }
            ;
            ?>
        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>





    <hr>
    <!-- área dos cards -->
    <div class="container-fluid bgcards card mt-4" style="justify-content:center; border:none;">
        <center>
            <div class="container">
                <div class="row mt-4">
                    <?php
                    foreach ($destaques as $produtoitem) {
                        $nome = $produtoitem['nome'];
                        $foto = $produtoitem['foto'];
                        $tipo = $produtoitem['tipo'];
                        $ativo = $produtoitem['ativo'];
                        $preco = $produtoitem['preco'];
                        $link = $produtoitem['link'];
                        if ($ativo == 'a') {


                            ?>
                            <div class="col-md-3 sm-12">
                                <div class="card prod" style="width: 16rem;">

                                    <a href="<?php echo $link ?>">
                                        <img src="<?php echo $foto ?>" alt="" srcset="" class="card-img-top imgem">
                                    </a>
                                    <div class="card-body" style="height:15rem">
                                        <h5 class="card-title">
                                            <?php echo $nome ?>
                                        </h5>
                                        <h4 class="price" style="font-size:large;">
                                            <font color="green">R$
                                                <?php echo $preco ?>
                                            </font>
                                        </h4>
                                    </div>
                                    <div style='padding-bottom: 20px;'>
                                        <a href="<?php echo $link ?>" class="btn btn-success">Conferir</a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ;
                    }
                    ;
                    ?>
                </div>
                <br>
            </div>
        </center>

    </div>

    <center>
        <h1>Destaques</h1>
      
        <div class="owl-carousel owl-theme container">
        <?php
            foreach ($destaques as $destaquesitem) {
                $nome = $destaquesitem['nome'];
                $foto = $destaquesitem['foto'];
                $tipo = $destaquesitem['tipo'];
                $ativo = $destaquesitem['ativo'];
                if ($ativo == 'a') {
                    ?>
            <div class="item">
                <a href="#"><img src="  <?php echo $foto ?>" alt="" srcset="" class="img-fluid" style="height: 200px; width:900px;"></a>
            </div>
            <?php
                  };
              };
            ?>
        </div>
    
    </center>
    <div class="mt-3">
        <footer class="bg-dark">
            <br>
            <div class="container footer-one">
                <div class="row mt-3">

                    <div class="col-md-2 sm-12 py-2 sm-2">
                        <img src="" alt="">
                    </div>


                    <div class="col-md-2 sm-12 py-2 sm-2 bg-dark">
                        <nav>
                            <ul class="" style="list-style: none;">
                                <a href="#" style="text-decoration: none;">
                                    <li class=" bg-dark text-white mouse">
                                        <h6>Termos de uso</h6>
                                    </li>
                                </a>
                                <hr>
                                <a href="" style="text-decoration: none;">
                                    <li class=" bg-dark text-white mouse">
                                        <h6>Políticas de privacidade</h6>
                                    </li>
                                </a>
                                <hr>
                                <a href="" style="text-decoration: none;">
                                    <li class=" bg-dark text-white mouse">
                                        <h6>Sobre nós</h6>
                                    </li>
                                </a>
                            </ul>
                        </nav>
                    </div>

                    <div class="col-md-4 sm-2 mt-5" style="text-align: center; ">
                        <p class="text-white">SIGA-NOS</p>
                        <a href="https://www.instagram.com/" target="_blank"><img src="img/instagram.png"
                                class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://br.linkedin.com/" target="_blank"><img src="img/linkedin.png"
                                class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://www.facebook.com/?locale=pt_BR" target="_blank"><img src="img/facebook.png"
                                class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://twitter.com/login?lang=pt" target="_blank"><img src="img/twitter.png"
                                class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://www.youtube.com/?hl=pt-br" target="_blank"><img src="img/youtube.png" class="img-fluid
                                rounded-start iconessociais" alt="Icone do GitHub"></a>
                    </div>




                </div>

                <div class="row mt-3">
                    <div class="col-md-12 text-white" style="justify-content: end;">
                        <p style="text-align: center;">&copy; 2023 - Todos os direitos reservados</p>
                        <p style="text-align: center;">Entre em contato pelo e-mail: bookstable@gmail.com</p>
                    </div>

                </div>
            </div>

    </div>
    </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
        
        <script>
            $(document).ready(function(){
                $(".owl-carousel").owlCarousel({
                  loop: true,
                  dots: true,
                  responsive:{
                    0 : {
                        items: 1
                    },
                    600 : {
                        items: 2
                    },
                   
                  },
                  autoplay: true,
                  autoplayHoverPause:true,
                  margin: 20,
              });
            })
        
        </script>
</body>

</html>