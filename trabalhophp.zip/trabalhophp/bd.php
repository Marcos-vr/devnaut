<?php

// session_start();
     
        $banner = [
          [
               'id' => '1',
               'nome' => 'banner1',
               'foto' => 'img/banner1.png',
               'tipo' => 'c',
               'ativo' => 'a'
          ],
          [
               'id' => '2',
               'nome' => 'banner2',
               'foto' => 'img/banner2.png',
               'tipo' => 'c',
               'ativo' => 'a'
          ],
          [
               'id' => '3',
               'nome' => 'banner3',
               'foto' => 'img/banner3.png',
               'tipo' => 'c',
               'ativo' => 'a'
          ],
     ];
    $produtos = [
     [
          'id' => '1',
          'nome' => 'Pai rico, Pai pobre',
          'foto' => 'img/opairico.jpg',
          'tipo' => 'p',
          'ativo' => 'a',
          'preco' => '45,90',
          'link' => 'produto1.php'

     ],
     [
          'id' => '2',
          'nome' => 'Minecraft | Guia de sobrevivência (Livro oficial ilustrado)',
          'foto' => 'img/minecraft.jpg',
          'tipo' => 'p',
          'ativo' => 'a',
          'preco' => '55,90',
          'link' => 'produto2.php'
     ],
     [
          'id' => '3',
          'nome' => 'A revolução dos bichos',
          'foto' => 'img/georgeorwel.jpg',
          'tipo' => 'p',
          'ativo' => 'a',
          'preco' => '39,90',
          'link' => 'produto1.php'
     ],
     [
          'id' => '4',
          'nome' => 'O deus que destrói sonhos',
          'foto' => 'img/odeusquedestroi.jpg',
          'tipo' => 'p',
          'ativo' => 'a',
          'preco' => '48,90',
          'link' => 'produto1.php'
     ]
     ];
     $destaques = [
          [
               'id' => '1',
               'nome' => 'destaque1',
               'foto' => 'img/nomedovento.jpg',
               'tipo' => 'd',
               'ativo' => 'a'
          ],
          [
               'id' => '2',
               'nome' => 'destaque2',
               'foto' => 'img/bruxo.jpeg',
               'tipo' => 'd',
               'ativo' => 'a'
          ],
          [
               'id' => '3',
               'nome' => 'destaque3',
               'foto' => 'img/aneis.jpg',
               'tipo' => 'd',
               'ativo' => 'a'
          ],
     ];
      
 ?>

