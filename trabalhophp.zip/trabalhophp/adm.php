<?php
session_start();
$adm = $_SESSION['index'];
if ($adm == 1) {
    $operador = 'adm';
} else {
    $operador = 'usuario';
};

include('bd.php');
?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg  sticky-top bg-dark">
        <div class="container bg-tertiary">
            <div><img src="img/estante-de-livros.png" alt=""></div>
            <a class="navbar-brand text-white ">
                <?php echo $operador ?>
            </a>

            <a class="navbar-brand  text-white" aria-current="page" href="#">
                <?php echo $_SESSION['nomeusuario'] ?>
            </a>


            <a class="navbar-brand text-white">
                <?php echo $_SESSION['nomeemail'] ?>
            </a>


            <a href="cadastro.php"> <button class="btn btn-outline-danger" type="submit">Sair</button></a>
        </div>
    </nav>


    <div class="container-fluid">
        <div class="row flex-nowrap ">
            <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
                <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">


                    <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start"
                        id="menu">


                        <li class="nav-item ">
                            <a href="adm.php?page=produtos" class="nav-link align-middle px-0">
                        <li class="fs-4 bi-house"></li><span class=" d-sm-inline text-white">Produtos</span>

                        </li>
                        </a>
                        <li class="nav-item">
                            <a href="adm.php?page=destaques" class="nav-link align-middle px-0">
                        <li class="fs-4 bi-house"></li><span class=" d-sm-inline text-white">Destaques</span>
                        </li>
                        </a>
                        <li class="nav-item">
                            <a href="adm.php?page=banner" class="nav-link align-middle px-0">
                        <li class="fs-4 bi-house"></li><span class=" d-sm-inline text-white">Banner</span>
                        </li>
                        </a>

                    </ul>
                </div>
            </div>

            <div class="col md-3">

                <?php
                if (isset($_GET['page']) && !empty($_GET['page'])) {
                    $nome = $_GET['page'];
                    if ($nome == 'ADM') {
                        include_once 'produtos.php';
                    } elseif ($nome == 'produtos') {
                        include_once 'produtos.php';
                    } elseif ($nome == 'destaques') {
                        include_once 'destaques.php';
                    } elseif ($nome == 'banner') {
                        include_once 'banner.php';
                    } else {
                        echo 'Erro 404';
                    }
                }
                ;
                ?>
            </div>





        </div>
    </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
</body>

</html>