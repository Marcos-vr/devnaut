<?php
include('bd.php');

if(isset($_POST['nome'])) {
    $destaques[] = [
        'id' => $_POST['id'],
        'nome' => $_POST['nome'],
        'tipo' => $_POST['tipo'],
        'ativo' => $_POST['ativo'],
        'foto' => $_POST['foto']
    ];
}

if (isset($_GET['id'])) {
    $idi = $_GET['id'];
    $indice = ($idi - 1);
    unset($destaques[$indice]);
} else {
    $idi = 0;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destaques</title>
</head>

<body>
    <div>
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="adm.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Destaques</li>
            </ol>
        </nav>
    </div>
    <div class="container">

        <div class="card" style="width: 80%; ">
            <div class="card-header col-md-12">
                #destaques
                <form action="./adm.php?page=destaques">
                    <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal1"
                        style="float: right;">
                        Cadastrar
                    </button>
                </form>
                <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form  action="./adm.php?page=destaques">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label for="formGroupExampleInput" class="form-label">
                                                id
                                            </label>
                                            <input type="text" class="form-control" id="formGroupExampleInput"
                                                placeholder="id" name="id">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="formGroupExampleInput" class="form-label">
                                                Nome
                                            </label>    
                                            <input type="text" class="form-control" id="formGroupExampleInput"
                                                placeholder="Nome" name="nome">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="formGroupExampleInput" class="form-label">
                                                Tipo
                                            </label>
                                            <input type="text" class="form-control" id="formGroupExampleInput"
                                                placeholder="Tipo" name="tipo">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="formGroupExampleInput2" class="form-label">
                                               Ativo 
                                            </label>
                                            <input type="text" class="form-control" id="formGroupExampleInput2"
                                                placeholder="Ativo" name="ativo">
                                        </div>
                                        <div class="col-md-9">
                                            <label for="formGroupExampleInput2" class="form-label">
                                                Foto
                                            </label>
                                            <input type="file" class="form-control" id="formFile"
                                                placeholder="..." name="foto">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <tbody class="table text-center" style="width: 80%;">
                    <tr class="text-center">
                        <th>Destaques</th>
                        <th>Ação</th>
                    </tr>
                    <tr>
                        <div class="row">
                            <?php
                            foreach ($destaques as $destaquesitem) {
                                $id = $destaquesitem['id'];
                                $nome = $destaquesitem['nome'];
                                $foto = $destaquesitem['foto'];
                                $tipo = $destaquesitem['tipo'];
                                $ativo = $destaquesitem['ativo'];
                                if ($tipo == 'd') {
                                    ?>
                                    <div class="col-md-6">
                                        <td>
                                            <img src="<?php echo $foto ?>" alt="" srcset=""
                                                class="card img-fluid rounded start">
                                        </td>
                                    </div>
                                    <div class="col-md-6">
                                        <td>
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <button type="button" class="btn btn-success">Ver +</button>
                                                <a href="adm.php?page=destaques&id=<?php echo $id; ?>" class="btn btn-info"
                                                    data-bs-toggle="modal" data-bs-target="#exampleModal">Editar</a>
                                                <a href="adm.php?page=destaques&id=<?php echo $id; ?>"
                                                    class="btn btn-danger">Excluir</a>
                                            </div>
                                        </td>
                                        <hr>
                                    </div>
                                    <?php
                                }
                            }
                            ;
                            ?>
                            <!-- Button trigger modal -->


                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php

                                            foreach ($destaques as $destaquesitem) {
                                                $id = $destaquesitem['id'];
                                                $nome = $destaquesitem['nome'];
                                                $foto = $destaquesitem['foto'];
                                                $tipo = $destaquesitem['tipo'];
                                                $ativo = $destaquesitem['ativo'];

                                                if ($id == $idi) {
                                                    ?>

                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </tbody>
            </div>
        </div>
    </div>
</body>

</html>''