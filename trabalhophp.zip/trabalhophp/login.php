<?php
session_start();


$_SESSION['nomeusuario'] = $_POST["usuarionome"];
$_SESSION['nomeemail'] = $_POST["usuarioemail"];

$senha = md5($_POST['senha']);
$senhaadm = '81dc9bdb52d04dc20036dbd8313ed055';//1234
$senhausuario = '7c75d66c6cdd272e847d465a73af39ff';//4321
// echo md5($senha);

if ($senha==$senhaadm){
     $_SESSION['index']=1;
     header('Location:adm.php');
 } else{
     header('Location: index1.php');
     $_SESSION['index']=2;
 }
   
 
 

?>   