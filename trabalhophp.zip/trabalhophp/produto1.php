<?php
session_start();
if (isset($_SESSION['index'])) {
    $adm = $_SESSION['index'];
} else {
    $adm = 0;
}

if (isset($adm) && !empty($adm)) {
    if ($adm == 1) {
        $operador = 'ADM';
    } elseif ($adm == 2) {
        $operador = $_SESSION['nomeusuario'];
    } elseif ($adm == 3) {
        $operador = 'Cliente';
    } else {
        $operador = '';
        session_destroy();
    }
} else {
    $operador = '';
};
// include('bd.php');

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <br>
    <title>Books on the <tb>
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300&family=Josefin+Sans:wght@600&display=swap" rel="stylesheet">

</head>

<body class="bg-light logo">
<nav class="navbar fixed-top navbar-expand-lg bg-secondary shadow" style="opacity: 0.95; height: 90px;">
        <div class="container-fluid bg-tertiary">
            <ul class="navbar-nav me-auto mb-1 mb-lg-0">
                <li class="nav-item logo text-white">
                    <a class="navbar-brand text-white shadow" href="#" >
                        <img src="img/icone.png" alt="">
                        <h5>Books on the ‹tb›</h5>
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <?php
                    if (!isset($_SESSION['index'])) {
                    ?>
                        <a class="nav-link  text-light" aria-current="page" href="./cadastro.php"><h5 class="mouse">Iniciar Sessão </h5> </a>
                        <?php echo ' ' . $operador; ?>
                </li>
            <?php
                    } else {
            ?>
                <a class="nav-link  text-light fixed-top text-center" aria-current="page" href="./cadastro.php"> </a><?php echo ' ' . $operador; ?>
                </li>
            <?php
                    }
            ?>

            </a>
            </li>
            <li class="nav-item">
                <a class="navbar-brand text-white">

                </a>
            </li>
            </ul>
            <a class="btn btn-danger" aria-current="page" href="./sair.php">Sair</a>
        </div>
    </nav>
    <br><br>
    
<div class="container">

    <div class="container sm-12" style="display: flexbox; justify-content: center;">
    <br>
    <div>
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index1.php"style="text-decoration:none;font-size: large;">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page" style="font-size: large;">Pai rico, pai pobre</li>
            </ol>
        </nav>
    </div>
        <div class="row mt-3" style="border: 1px solid gray">
            <div class="container col-md-3 sm-12">
                
                <img src="img/opairico2.jpg" class="img-fluid rounded-start mt-5" width="100%" alt="" >
            </div>
            <div class="col-md-5 sm-12">
              <br>
              <br>
                <div class="container">
                    <div class="mt-3  text-black" style="border: 1px solid gray; margin: 10px; padding: 10px; padding-bottom: 1em; border-radius: 10px;">
                      <h5>Descrição</h5>
                      <p>Os monitores Gamer Ninja trazem um ótimo desempenho para você ter uma experiência surpreendente com gráficos fluídos e de altíssima qualidade! O monitor é equipado com tela Full HD, painel IPS, uma taxa de atualização de 75Hz, tempo de resposta de 5ms, tecnologia FreeSync e Flicker Free.Com a resolução Full HD, seu novo monitor terá 1920 x 1080 pixels, perfeito para você apreciar seus jogos e não perder um detalhe do campo de batalha.</p>
                      <br>
                      <br>
                      <hr>
                        <div class="row d-flex">
                        <div class="col-md-12 sm-12" style="padding: 40px;">  
                          <a href="#"  class="btn btn-verde comprar" style="width: 100%; padding: 5px;" data-bs-toggle="modal" data-bs-target="#exampleModal"><h4 class="text-black">Comprar</h4></a>
                        </div>      
                        </div>    
                    </div>
                    
                </div>
            </div>
        
        
        
        </div>

    </div>
  </div>   
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card mb-3" style="max-width: 540px;">
                            <div class="row g-0">
                                <div class="col-md-8">
                                    <div class="card-body">

                                    <?php
                                    if (!isset($_SESSION['index'])) {
                                    ?>
                                    <h5 class="card-title">É necessário fazer o login.</h5>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <form name="modal" method="Post" action="cadastro.php">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-success">Logar</button>
                        </form>
                        <?php 
                    }else {
                        ?>
                        <h5 class="card-title">Você sera direcionado para outra pagina</h5>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <form name="modal" method="Post" action="concluircompra.php">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">Alugar</button>
                            
                            <button type="submit" class="btn btn-success">Comprar</button>
                        </form>
                        <?php
                    }
                        ?>
                    </div>
                </div>
            </div>
        </div>
  <div class="mt-5">
        <footer class="bg-dark">
            <br>
            <div class="container footer-one">
                <div class="row mt-3">

                    <div class="col-md-2 sm-12 py-2 sm-2">
                        <img src="" alt="">
                    </div>


                    <div class="col-md-2 sm-12 py-2 sm-2 bg-dark">
                        <nav>
                            <ul class="" style="list-style: none;">
                                <a href="#" style="text-decoration: none;">
                                    <li class=" bg-dark text-white mouse">
                                        <h6>Termos de uso</h6>
                                    </li>
                                </a>
                                <hr>
                                <a href="" style="text-decoration: none;">
                                    <li class=" bg-dark text-white mouse">
                                        <h6>Políticas de privacidade</h6>
                                    </li>
                                </a>
                                <hr>
                                <a href="" style="text-decoration: none;">
                                    <li class=" bg-dark text-white mouse">
                                        <h6>Sobre nós</h6>
                                    </li>
                                </a>
                            </ul>
                        </nav>
                    </div>

                    <div class="col-md-4 sm-2 mt-5" style="text-align: center; ">
                        <p class="text-white">SIGA-NOS</p>
                        <a href="https://www.instagram.com/" target="_blank"><img src="img/instagram.png" class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://br.linkedin.com/" target="_blank"><img src="img/linkedin.png" class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://www.facebook.com/?locale=pt_BR" target="_blank"><img src="img/facebook.png" class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://twitter.com/login?lang=pt" target="_blank"><img src="img/twitter.png" class="img-fluid rounded-start iconessociais shadow imgem" alt="Icone do GitHub"></a>
                        <a href="https://www.youtube.com/?hl=pt-br" target="_blank"><img src="img/youtube.png" class="img-fluid
                                rounded-start iconessociais" alt="Icone do GitHub"></a>
                    </div>




                </div>

                <div class="row mt-3">
                    <div class="col-md-12 text-white" style="justify-content: end;">
                        <p style="text-align: center;">&copy; 2023 - Todos os direitos reservados</p>
                        <p style="text-align: center;">Entre em contato pelo e-mail: bookstable@gmail.com</p>
                    </div>

                </div>
            </div>

    </div>

    </footer>
    </div>

    <script src="js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>