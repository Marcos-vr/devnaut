<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
?>

<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  </head>
  <body>

 <nav class="navbar navbar-expand-lg bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="inicial.php" style="width:70px"> <img src="./img/barbeariaLogo.png" style="width:130px" alt=""></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        
      <div class="position-absolute top-0 start-50 translate-middle mt-4">
      
      </ul>
      </div>

                            
                           
    </div>
  </div>
</nav> 






<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-3 px-0 bg-dark">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline bordahover me-3">Menu</span>
                </a>

                <a onclick="carregarConteudo('listarproduto')" href="#" style="text-decoration:none;" class="text-white">
      <i class="bi bi-archive"></i>
      <span>Produto</span>
    </a>

    <a onclick="carregarConteudo('listaragenda')" href="#" style="text-decoration:none;" class="text-white mt-3">
      <i class="bi bi-person-circle"></i>
      <span>Profissionais</span>
    </a>
                        

                        

                       

    
                  
                
<span class="mt-3"><a onclick="carregarConteudo('dddd')" href="#" style="text-decoration:none;" class="text-white">
      <i class="bi bi-calendar"></i>
      <span>Agenda</span>
    </a>

    
        </div>
        </div>
        <div id="conteudo" class="col py-3 bg-white">
      
        </div>
    </div>
</div>
</span>



      
        
<!-- Modal  de Cadastro de serviço-->
<div class="modal fade" id="modalAddservico"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"> <i class="bi bi-upload"></i> Adicionar serviço</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmCadServico" id="frmCadServico" action="#"  method="post"  >
  <div class="mb-3">
    <label for="idServico" class="form-label">Serviço</label>
    <input type="text" class="form-control" name="servico" id="idServico">
   
  </div>

  <button type="submit" id="btnAddServico" class="btn btn-primary">Adicionar</button>

</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
     
      </div>
    </div>
  </div>
</div>

<!-- Modal  de editar servicos-->
<div class="modal fade" id="modaleditservico"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"><i class="bi bi-box-arrow-in-up-left"></i> Alterar serviço</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form name="frmeditservico" id="frmeditservico" action="#"  method="post"  >
  <div class="mb-3">
    <label for="generoedit" class="form-label">Alterar servico</label>
    <input type="text" class="form-control" name="servicoedit1" id="servicoedit" aria-describedby="emailHelp"  >

    <input type="hidden" class="form-control mt-3" name="idservicoedit" id="idservicoedit" aria-describedby="emailHelp"  >
  </div>

  
  <button type="submit" id="btneditgenero" class="btn btn-primary" >Adicionar</button>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
     
      </div>
    </div>
  </div>
</div>

<!-- Modal  de Cadastro de Clientes-->

<div class="modal fade" id="modalAddcliente"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"><i class="bi bi-upload"></i> Adicionar Cliente</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form name="frmAddcliente" id="frmAddcliente" action="#"  method="post"  >
  <div class="mb-3">
    <label for="idcliente1" class="form-label">Nome</label>
    <input type="text" class="form-control" name="nomecliente" id="idnomecliente" aria-describedby="emailHelp" required=required  >
    <label for="idcliente2" class="form-label">Email</label>
    <input type="text" class="form-control" name="emailcliente" id="idemailcliente" aria-describedby="emailHelp" required=required   >
    <label for="idcliente2" class="form-label">CPF</label>
    <input type="text" class="form-control" name="cpfcliente" id="idcpfcliente" aria-describedby="emailHelp" required=required   >
   
  </div>

  <button type="submit" id="btnAddcliente" class="btn btn-primary">Adicionar</button>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
     
      </div>
    </div>
  </div>
</div>





<!-- Modal  de Cadastro de Adm-->

<div class="modal fade" id="modalAddadm"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"><i class="bi bi-upload"></i> Adicionar adm</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form name="frmAddadm" id="frmAddadm" action="#"  method="post"  >
  <div class="mb-3">
    <label for="idcliente1" class="form-label">Nome</label>
    <input type="text" class="form-control" name="nomeadm" id="idnomeadm" aria-describedby="emailHelp" required=required  >
    <label for="idcliente2" class="form-label">Email</label>
    <input type="text" class="form-control" name="emailadm" id="idemailadm" aria-describedby="emailHelp" required=required   >
    <label for="idcliente2" class="form-label">Senha</label>
    <input type="text" class="form-control" name="senhaadm" id="idsenhaadm" aria-describedby="emailHelp" required=required   >
   
  </div>

  <button type="submit" id="btnAddadm" class="btn btn-primary">Adicionar</button>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
     
      </div>
    </div>
  </div>
</div>

<!-- Modal  de editar  Adm-->

<div class="modal fade" id="modaleditadm"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"><i class="bi bi-box-arrow-in-up-left"></i> Alterar Cliente</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form name="frmeditadm" id="frmeditadm" action="#"  method="post"  >
  <div class="mb-3">
    <label for="idnomeadmedit" class="form-label">Alterar Cliente</label>
    <input type="text" class="form-control" name="admeditnome" id="idnomeadmedit" aria-describedby="emailHelp" placeholder="Altere o cliente"  >

    <input type="text" class="form-control mt-3" name="admemailledit" id="idemailadmedit" aria-describedby="emailHelp" placeholder="Altere o email">
    <input type="text" class="form-control mt-3" name="admsenhaedit" id="idadmsenhaedit" aria-describedby="emailHelp" placeholder="Altere o cpf"  >

    <input type="hidden" class="form-control mt-3" name="idadmeditt" id="idadmedit" aria-describedby="emailHelp"  >
  </div>
  <button type="submit" id="btneditadm" class="btn btn-primary">Adicionar</button>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
     
      </div>
    </div>
  </div>
</div>



<!-- Modal  de editar  Clientes-->

<div class="modal fade" id="modaleditcliente"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"><i class="bi bi-box-arrow-in-up-left"></i> Alterar Cliente</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form name="frmeditcliente" id="frmeditcliente" action="#"  method="post"  >
  <div class="mb-3">
    <label for="clienteedit" class="form-label">Alterar Cliente</label>
    <input type="text" class="form-control" name="nomeedit" id="idnomedit" aria-describedby="emailHelp" placeholder="Altere o cliente"  >

    <input type="text" class="form-control mt-3" name="emailedit" id="idemailedit" aria-describedby="emailHelp" placeholder="Altere o email">
    <input type="text" class="form-control mt-3" name="cpfedit" id="idcpfedit" aria-describedby="emailHelp" placeholder="Altere o cpf"  >

    <input type="hidden" class="form-control mt-3" name="idcliente" id="idclienteedit" aria-describedby="emailHelp"  >
  </div>
  <button type="submit" id="btneditcliente" class="btn btn-primary">Adicionar</button>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
     
      </div>
    </div>
  </div>
</div>


<!-- Modal  de ver mais Generos-->

<div class="modal fade" id="vermais" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form name="frmvermais" id="frmvermais" action="#"  method="post"  >
  <div class="mb-3">
    <label for="clienteedit" class="form-label">Alterar Cliente</label>
    <input type="text" class="form-control" name="genero" id="generovermais" aria-describedby="emailHelp" placeholder="Altere o cliente"  >
    <input type="text" class="form-control mt-3" name="generovermais" id="idgenerovermais" aria-describedby="emailHelp"  >
  </div>

</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal  de ver mais clientes-->

<div class="modal fade" id="vermaiscliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form name="frmvermais" id="frmvermais" action="#"  method="post"  >
  <div class="mb-3">
    <label for="clienteedit" class="form-label">Alterar Cliente</label>
    <input type="text" class="form-control" name="cliente" id="clientevermais" aria-describedby="emailHelp" placeholder="Altere o cliente"  >
    <input type="text" class="form-control mt-3" name="clientevermais" id="idclientevermais" aria-describedby="emailHelp"  >
  </div>

</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>




<!-- Modal  de Cadastro de Pedido-->

<div class="modal fade" id="modalAddpedido" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"><i class="bi bi-upload"></i> Adicionar Pedido</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmAddpedido" id="frmAddpedido" action="#"  method="post"  >
          <div class="mb-3">
            <label for="sclientep" class="form-label">Cliente</label>
            <select name="selectclientepedido" class="form-control" id="sclientep">
              <?php
              
              ?>
            </select>

            <label for="sservicop" class="form-label">Tipo do serviço</label>
           

          <div class="row">
            <h5>Prazo de entrega</h5>
            <div class="col-md-6">
              <label for="">Datainicio</label>
              <input type="date" name="datainicio" id="iddatainicio">
            </div>

            <div class="col-md-6">
              <label for="">Datafim</label>
              <input type="date" name="datafim" id="iddatafim">
            </div>
          </div>

          <label for="idvalorcontra" class="form-label">Valor contratado</label>
          <input type="text" class="form-control" name="valorcontra" id="idvalorcontra" aria-describedby="emailHelp">

          <label>
            <input type="radio" name="pagamento" value="a_vista" id="idvista" checked> A vista
          </label>
          <br>
          <label>
            <input type="radio" name="pagamento" value="a_prazo" id="idprazo"> A prazo
          </label>
          <br>
          <div id="prazoInput">
            <label for="prazo">Valor entrada</label>
            <input type="text" id="idprazo" name="prazo">
          </div>

          <label for="sadmp" class="form-label">Quem recebeu o pagamento?</label>
          <select name="selectadmpedido" class="form-control" id="sadmp">
    
            ?>
          </select>

          <button type="submit" id="btnAddpedido" class="btn btn-primary mt-4">Adicionar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>







    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>



  </body>
</html>
